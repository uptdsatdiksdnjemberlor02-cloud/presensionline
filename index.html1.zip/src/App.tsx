/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab, AppConfig, AttendanceRecord, Student } from './types/index.ts';
import {
  loadStoredConfig,
  saveStoredConfig,
  loadStoredStudents,
  saveStoredStudents,
  loadStoredAttendance,
  saveStoredAttendance,
  loadStoredAuth,
  saveStoredAuth,
  INITIAL_STUDENTS,
  generateInitialAttendance,
  DEFAULT_CONFIG,
} from './utils/storage.ts';
import { Navbar } from './components/Navbar.tsx';
import { LoginView } from './components/LoginView.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { StudentsView } from './components/StudentsView.tsx';
import { PrintQrView } from './components/PrintQrView.tsx';
import { ScanQrView } from './components/ScanQrView.tsx';
import { RecapView } from './components/RecapView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { LegalBadge } from './components/LegalBadge.tsx';

export default function App() {
  const [config, setConfig] = useState<AppConfig>(loadStoredConfig);
  const [students, setStudents] = useState<Student[]>(loadStoredStudents);
  const [records, setRecords] = useState<AttendanceRecord[]>(loadStoredAttendance);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    // Support ?autostart=1 for ultra-mode instant testing verification
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('autostart') === '1') {
        return true;
      }
    }
    return loadStoredAuth();
  });

  // Save config changes to localStorage
  const handleSaveConfig = (newConfig: AppConfig) => {
    setConfig(newConfig);
    saveStoredConfig(newConfig);
    // Sync browser document title with updated config panelTitle
    if (typeof document !== 'undefined') {
      document.title = `${newConfig.panelTitle} - ${newConfig.schoolName}`;
    }
  };

  // Save student changes
  const handleSaveStudents = (newStudents: Student[]) => {
    setStudents(newStudents);
    saveStoredStudents(newStudents);
  };

  // Add new attendance record
  const handleRecordAttendance = (newRecord: AttendanceRecord) => {
    setRecords((prev) => {
      // If already exists with same student & date, replace (for example adding waktuPulang)
      const existingIdx = prev.findIndex(
        (r) => r.studentId === newRecord.studentId && r.tanggal === newRecord.tanggal
      );
      let updated: AttendanceRecord[];
      if (existingIdx >= 0) {
        updated = [...prev];
        updated[existingIdx] = newRecord;
      } else {
        updated = [newRecord, ...prev];
      }
      saveStoredAttendance(updated);
      return updated;
    });
  };

  // Update attendance records
  const handleUpdateRecords = (updatedRecords: AttendanceRecord[]) => {
    setRecords(updatedRecords);
    saveStoredAttendance(updatedRecords);
  };

  // Reset Demo Data
  const handleResetDemoData = () => {
    setStudents(INITIAL_STUDENTS);
    saveStoredStudents(INITIAL_STUDENTS);
    const initialAtt = generateInitialAttendance(INITIAL_STUDENTS);
    setRecords(initialAtt);
    saveStoredAttendance(initialAtt);
    setConfig(DEFAULT_CONFIG);
    saveStoredConfig(DEFAULT_CONFIG);
    alert('Data contoh demo berhasil direset ke setelan awal.');
  };

  // Restore from backup
  const handleRestoreBackup = (data: {
    config?: AppConfig;
    students?: Student[];
    records?: AttendanceRecord[];
  }) => {
    if (data.config) {
      setConfig(data.config);
      saveStoredConfig(data.config);
    }
    if (data.students) {
      setStudents(data.students);
      saveStoredStudents(data.students);
    }
    if (data.records) {
      setRecords(data.records);
      saveStoredAttendance(data.records);
    }
  };

  // Authentication Handlers
  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
    saveStoredAuth(true);
  };

  const handleLogout = () => {
    if (confirm('Apakah Anda yakin ingin keluar dari Admin Panel?')) {
      setIsAuthenticated(false);
      saveStoredAuth(false);
    }
  };

  // Update document title on load
  useEffect(() => {
    document.title = `${config.panelTitle} - ${config.schoolName}`;
  }, [config.panelTitle, config.schoolName]);

  // If not authenticated, show login view
  if (!isAuthenticated) {
    return <LoginView config={config} onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Main Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        config={config}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            students={students}
            records={records}
            config={config}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'students' && (
          <StudentsView
            students={students}
            onSaveStudents={handleSaveStudents}
            onSelectForQr={(student) => {
              setActiveTab('print_qr');
            }}
          />
        )}

        {activeTab === 'print_qr' && (
          <PrintQrView students={students} config={config} />
        )}

        {activeTab === 'scan_qr' && (
          <ScanQrView
            students={students}
            records={records}
            config={config}
            onRecordAttendance={handleRecordAttendance}
          />
        )}

        {activeTab === 'recap' && (
          <RecapView
            records={records}
            students={students}
            config={config}
            onUpdateRecords={handleUpdateRecords}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            config={config}
            onSaveConfig={handleSaveConfig}
            students={students}
            records={records}
            onResetDemoData={handleResetDemoData}
            onRestoreBackup={handleRestoreBackup}
          />
        )}
      </main>

      {/* Required Legalitas: 'by Kunti Kunanti, M.Pd.' at bottom right */}
      <LegalBadge legalText={config.footerLegal} />
    </div>
  );
}
