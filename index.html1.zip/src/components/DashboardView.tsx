import React from 'react';
import {
  Users,
  CheckCircle,
  ClockAlert,
  CalendarCheck,
  AlertOctagon,
  ScanLine,
  QrCode,
  UserPlus,
  ArrowRight,
  TrendingUp,
  School,
  FileSpreadsheet,
} from 'lucide-react';
import { ActiveTab, AppConfig, AttendanceRecord, Student } from '../types/index.ts';
import { computeAttendanceStats } from '../utils/attendanceLogic.ts';
import { getTodayDateString } from '../utils/storage.ts';

interface DashboardViewProps {
  students: Student[];
  records: AttendanceRecord[];
  config: AppConfig;
  onNavigate: (tab: ActiveTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  students,
  records,
  config,
  onNavigate,
}) => {
  const today = getTodayDateString();
  const stats = computeAttendanceStats(students, records, today);
  const todayRecords = records.filter((r) => r.tanggal === today).slice(0, 7);

  const formattedDate = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const maleCount = students.filter((s) => s.jenisKelamin === 'L').length;
  const femaleCount = students.filter((s) => s.jenisKelamin === 'P').length;

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 border border-indigo-800/40 p-6 sm:p-8 shadow-xl">
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-semibold">
              <School className="w-3.5 h-3.5" />
              <span>{config.schoolName}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {config.panelTitle}
            </h1>
            <p className="text-sm text-slate-300 max-w-xl">
              Sistem presensi digital QR Code berbasis NIS siswa. Praktis, cepat, dan terhubung langsung dengan kamera perangkat.
            </p>
            <div className="pt-1 flex flex-wrap items-center gap-4 text-xs text-slate-400">
              <span className="flex items-center gap-1.5 font-medium text-slate-200">
                <CalendarCheck className="w-4 h-4 text-emerald-400" />
                {formattedDate}
              </span>
              <span className="flex items-center gap-1.5 font-medium text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded-md border border-amber-500/30">
                <ClockAlert className="w-3.5 h-3.5 text-amber-400" />
                Batas Jam Masuk: {config.lateThreshold} WIB
              </span>
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3 shrink-0">
            <button
              onClick={() => onNavigate('scan_qr')}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] group"
            >
              <ScanLine className="w-4 h-4 group-hover:rotate-12 transition-transform" />
              <span>Buka Scanner Kamera</span>
            </button>
            <button
              onClick={() => onNavigate('print_qr')}
              className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-slate-800/80 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700 flex items-center justify-center gap-2 transition-all"
            >
              <QrCode className="w-4 h-4 text-indigo-400" />
              <span>Cetak Kartu QR</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Siswa */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Total Siswa</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{stats.totalStudents}</div>
          <span className="text-[11px] text-slate-500">
            {maleCount} L • {femaleCount} P
          </span>
        </div>

        {/* Hadir Tepat Waktu */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-all">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Hadir Tepat</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-400">{stats.hadirCount}</div>
          <span className="text-[11px] text-emerald-500/80">≤ {config.lateThreshold} WIB</span>
        </div>

        {/* Terlambat */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Terlambat</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <ClockAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-400">{stats.terlambatCount}</div>
          <span className="text-[11px] text-amber-500/80">&gt; {config.lateThreshold} WIB</span>
        </div>

        {/* Izin / Sakit */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-sky-500/40 transition-all">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Izin / Sakit</span>
            <div className="w-8 h-8 rounded-xl bg-sky-500/10 flex items-center justify-center text-sky-400">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-sky-400">{stats.izinCount + stats.sakitCount}</div>
          <span className="text-[11px] text-sky-500/80">Dengan surat</span>
        </div>

        {/* Belum Absen */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-rose-500/40 transition-all">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400">Belum Hadir</span>
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-400">
              <AlertOctagon className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-rose-400">{stats.belumAbsenCount}</div>
          <span className="text-[11px] text-rose-500/80">Alpa / Belum Scan</span>
        </div>

        {/* Persentase Kehadiran */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-900/60 to-slate-900 border border-indigo-700/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-indigo-300">Persentase</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-300">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{stats.presentRate}%</div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
            <div
              className="bg-emerald-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, stats.presentRate)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Grid: Gender Distribution & Live Scans */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Distribusi Kehadiran Berdasarkan Jenis Kelamin */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Kehadiran Berdasarkan Jenis Kelamin
              </h2>
              <p className="text-xs text-slate-400">
                Data presensi siswa Laki-laki (L) dan Perempuan (P)
              </p>
            </div>
            <button
              onClick={() => onNavigate('recap')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <span>Detail</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4">
            {/* Laki-laki */}
            <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800/80">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-blue-300 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  Siswa Laki-laki (L)
                </span>
                <span className="font-mono text-slate-300">
                  <strong className="text-emerald-400">{stats.genderBreakdown.L.hadir}</strong> / {stats.genderBreakdown.L.total} Hadir
                </span>
              </div>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-blue-500 h-full rounded-full transition-all"
                  style={{
                    width: `${
                      stats.genderBreakdown.L.total > 0
                        ? (stats.genderBreakdown.L.hadir / stats.genderBreakdown.L.total) * 100
                        : 0
                    }%`,
                  }}
                />
              </div>
            </div>

            {/* Perempuan */}
            <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800/80">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-pink-300 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-pink-500" />
                  Siswa Perempuan (P)
                </span>
                <span className="font-mono text-slate-300">
                  <strong className="text-emerald-400">{stats.genderBreakdown.P.hadir}</strong> / {stats.genderBreakdown.P.total} Hadir
                </span>
              </div>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-pink-500 h-full rounded-full transition-all"
                  style={{
                    width: `${
                      stats.genderBreakdown.P.total > 0
                        ? (stats.genderBreakdown.P.hadir / stats.genderBreakdown.P.total) * 100
                        : 0
                    }%`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Aktivitas Presensi Terkini */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-base font-bold text-white tracking-tight">
                  Aktivitas Presensi Terkini
                </h2>
                <p className="text-xs text-slate-400">
                  Riwayat scan QR code terbaru yang tercatat sistem
                </p>
              </div>
              <button
                onClick={() => onNavigate('scan_qr')}
                className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20 transition-all flex items-center gap-1.5"
              >
                <ScanLine className="w-3.5 h-3.5" />
                <span>Scan Baru</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {todayRecords.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Belum ada catatan presensi hari ini. Silakan mulai scan QR code siswa.
                </div>
              ) : (
                todayRecords.map((rec) => {
                  const isLate = rec.status === 'Terlambat';
                  const isPresent = rec.status === 'Hadir';
                  return (
                    <div
                      key={rec.id}
                      className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                            isPresent
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : isLate
                              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                              : 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/30'
                          }`}
                        >
                          {rec.nama.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-200 line-clamp-1">
                            {rec.nama}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            NIS: {rec.nis}
                          </div>
                        </div>
                      </div>

                      <div className="text-right flex flex-col items-end">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isPresent
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : isLate
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                          }`}
                        >
                          {rec.status}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {rec.waktuMasuk} WIB
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-400" />
              Total {records.length} riwayat presensi tersimpan
            </span>
            <button
              onClick={() => onNavigate('recap')}
              className="text-indigo-400 hover:text-white font-semibold transition-colors flex items-center gap-1"
            >
              <span>Buka Menu Rekap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
        <div
          onClick={() => onNavigate('students')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900 transition-all cursor-pointer group flex items-start gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0 group-hover:bg-indigo-500 group-hover:text-white transition-all">
            <UserPlus className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
              Input Data Siswa
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Input data siswa ringkas dengan kolom No, NIS, Nama, dan Jenis Kelamin
            </p>
          </div>
        </div>

        <div
          onClick={() => onNavigate('print_qr')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900 transition-all cursor-pointer group flex items-start gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 group-hover:bg-emerald-500 group-hover:text-white transition-all">
            <QrCode className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
              Cetak Kartu QR Siswa
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Desain kartu identitas siswa siap cetak dengan logo instansi dan kode QR NIS
            </p>
          </div>
        </div>

        <div
          onClick={() => onNavigate('settings')}
          className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-900 transition-all cursor-pointer group flex items-start gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0 group-hover:bg-amber-500 group-hover:text-white transition-all">
            <School className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
              Pengaturan & Logo Instansi
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Unggah foto logo sekolah, ubah judul admin panel, identitas dan jam keterlambatan
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
