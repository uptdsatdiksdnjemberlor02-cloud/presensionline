import React from 'react';
import { Award, ShieldCheck } from 'lucide-react';

interface LegalBadgeProps {
  legalText?: string;
}

export const LegalBadge: React.FC<LegalBadgeProps> = ({
  legalText = 'by Kunti Kunanti, M.Pd.',
}) => {
  return (
    <aside 
      aria-label="Informasi Legalitas Sistem"
      className="fixed bottom-3 right-3 z-40 print:hidden pointer-events-auto"
    >
      <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-amber-500/30 text-amber-300 shadow-lg shadow-black/40 backdrop-blur-md transition-all hover:border-amber-400 hover:scale-105 select-none">
        <div className="relative flex items-center justify-center">
          <ShieldCheck className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
        </div>
        <div className="flex flex-col leading-none">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            Legalitas Sistem
          </span>
          <span className="text-xs font-bold text-amber-300 tracking-tight flex items-center gap-1">
            <Award className="w-3 h-3 text-amber-400 inline" />
            {legalText}
          </span>
        </div>
      </div>
    </aside>
  );
};
