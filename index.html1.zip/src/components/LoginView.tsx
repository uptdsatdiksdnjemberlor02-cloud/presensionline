import React, { useState } from 'react';
import { Shield, Lock, Eye, EyeOff, ArrowRight, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import { AppConfig } from '../types/index.ts';
import { LegalBadge } from './LegalBadge.tsx';

interface LoginViewProps {
  config: AppConfig;
  onLoginSuccess: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ config, onLoginSuccess }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    setTimeout(() => {
      // Validate with custom password from config
      if (password === config.adminPassword) {
        setIsLoading(false);
        onLoginSuccess();
      } else {
        setIsLoading(false);
        setError('Password admin salah. Silakan periksa kembali!');
      }
    }, 300);
  };

  const handleUseDemoPassword = () => {
    setPassword(config.adminPassword);
    setError(null);
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex flex-col items-center justify-center p-4">
      {/* Background Decorative Rings */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Card Header with School Logo & Title */}
        <div className="text-center mb-6">
          <div className="relative inline-block mb-3">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-slate-800 p-2 border-2 border-indigo-500/30 shadow-2xl shadow-indigo-500/20 flex items-center justify-center overflow-hidden">
              {config.logoBase64 ? (
                <img
                  src={config.logoBase64}
                  alt={config.schoolName}
                  className="w-full h-full object-contain"
                />
              ) : (
                <Shield className="w-10 h-10 text-indigo-400" />
              )}
            </div>
            <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded-full border border-slate-900 shadow">
              ADMIN
            </span>
          </div>

          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            {config.panelTitle}
          </h1>
          <p className="text-sm font-medium text-indigo-300 mt-1">
            {config.schoolName}
          </p>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto line-clamp-1">
            {config.schoolTagline}
          </p>
        </div>

        {/* Login Box */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
          <div className="flex items-center gap-2 mb-5 pb-3 border-b border-slate-800 text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <Lock className="w-4 h-4 text-indigo-400" />
            <span>Autentikasi Administrator</span>
          </div>

          {error && (
            <div
              role="alert"
              className="mb-5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 animate-shake"
            >
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="admin-password"
                className="block text-xs font-semibold text-slate-300 mb-1.5"
              >
                Password Admin Sistem
              </label>
              <div className="relative">
                <input
                  id="admin-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Masukkan password admin..."
                  required
                  autoFocus
                  className="w-full pl-4 pr-11 py-3 rounded-xl bg-slate-950/70 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Sembunyikan password' : 'Lihat password'}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || !password}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-indigo-600 hover:from-indigo-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed group active:scale-[0.98]"
            >
              <span>{isLoading ? 'Memverifikasi...' : 'Masuk ke Admin Panel'}</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </form>

          {/* Quick Helper for Custom / Default Password */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Password Default:</span>
            <button
              type="button"
              onClick={handleUseDemoPassword}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 font-mono text-xs border border-indigo-500/30 transition-all"
            >
              <Sparkles className="w-3 h-3 text-indigo-400" />
              <span>Gunakan: {config.adminPassword}</span>
            </button>
          </div>

          <div className="mt-4 text-[11px] text-slate-500 text-center flex items-center justify-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 inline" />
            <span>Hak Akses: Khusus Admin Instansi (Siswa Tidak Memiliki Akses)</span>
          </div>
        </div>
      </div>

      {/* Required Legal attribution in bottom right corner */}
      <LegalBadge legalText={config.footerLegal} />
    </div>
  );
};
