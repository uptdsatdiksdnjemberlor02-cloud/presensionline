import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  QrCode,
  ScanLine,
  FileSpreadsheet,
  Settings,
  LogOut,
  Clock,
  Menu,
  X,
  School,
} from 'lucide-react';
import { ActiveTab, AppConfig } from '../types/index.ts';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  config: AppConfig;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  config,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
      setCurrentDate(
        now.toLocaleDateString('id-ID', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        })
      );
    };

    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'students' as ActiveTab,
      label: 'Data Siswa',
      icon: Users,
      badge: null,
    },
    {
      id: 'print_qr' as ActiveTab,
      label: 'Cetak QR Code',
      icon: QrCode,
      badge: 'Cetak',
    },
    {
      id: 'scan_qr' as ActiveTab,
      label: 'Scan QR Code',
      icon: ScanLine,
      badge: 'Kamera',
      highlight: true,
    },
    {
      id: 'recap' as ActiveTab,
      label: 'Rekap Absensi',
      icon: FileSpreadsheet,
      badge: null,
    },
    {
      id: 'settings' as ActiveTab,
      label: 'Pengaturan',
      icon: Settings,
      badge: null,
    },
  ];

  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800 backdrop-blur-md print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & School / Panel Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-indigo-500/30 flex items-center justify-center p-1 overflow-hidden shrink-0 shadow-md shadow-indigo-500/10">
              {config.logoBase64 ? (
                <img
                  src={config.logoBase64}
                  alt={config.schoolName}
                  className="w-full h-full object-contain"
                />
              ) : (
                <School className="w-5 h-5 text-indigo-400" />
              )}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-extrabold text-white tracking-tight leading-tight flex items-center gap-2">
                {config.panelTitle}
                <span className="hidden sm:inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ADMIN
                </span>
              </span>
              <span className="text-xs text-slate-400 leading-tight truncate max-w-[200px] sm:max-w-xs">
                {config.schoolName}
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav aria-label="Menu Utama" className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all relative ${
                    isActive
                      ? item.highlight
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-500/20'
                        : 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                      : item.highlight
                      ? 'bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 border border-emerald-500/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && !isActive && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-800 text-slate-300 font-normal">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Area: Realtime Clock & Logout */}
          <div className="hidden sm:flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
              <Clock className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              <div className="flex flex-col text-right font-mono">
                <span className="font-bold text-slate-200">{currentTime} WIB</span>
                <span className="text-[10px] text-slate-400 font-sans">{currentDate}</span>
              </div>
            </div>

            <button
              onClick={onLogout}
              title="Keluar dari Admin Panel"
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition-all"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => onTabChange('scan_qr')}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${
                activeTab === 'scan_qr'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              }`}
            >
              <ScanLine className="w-4 h-4" />
              <span className="hidden xs:inline">Scan</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-900/98 px-4 pt-3 pb-4 space-y-1">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-800 text-xs text-slate-400">
            <span>Waktu Server:</span>
            <span className="font-mono font-semibold text-indigo-300">
              {currentDate} • {currentTime} WIB
            </span>
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onLogout();
              }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-500/10 transition-all"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar (Logout)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
