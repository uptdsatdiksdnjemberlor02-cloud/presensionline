import React, { useState, useEffect } from 'react';
import {
  Printer,
  QrCode,
  Download,
  CheckSquare,
  Square,
  School,
  IdCard,
  Info,
} from 'lucide-react';
import QRCode from 'qrcode';
import { AppConfig, Student } from '../types/index.ts';

interface PrintQrViewProps {
  students: Student[];
  config: AppConfig;
}

export const PrintQrView: React.FC<PrintQrViewProps> = ({ students, config }) => {
  const [selectedGender, setSelectedGender] = useState<string>('SEMUA');
  const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(
    new Set(students.map((s) => s.id))
  );
  const [cardLayout, setCardLayout] = useState<'id_card' | 'compact_badge'>('id_card');

  const filteredStudents = students.filter((s) => {
    if (selectedGender !== 'SEMUA' && s.jenisKelamin !== selectedGender) return false;
    return true;
  });

  // Sync selection when filter changes
  useEffect(() => {
    setSelectedStudentIds(new Set(filteredStudents.map((s) => s.id)));
  }, [selectedGender, students.length]);

  const handleToggleSelectAll = () => {
    if (selectedStudentIds.size === filteredStudents.length) {
      setSelectedStudentIds(new Set());
    } else {
      setSelectedStudentIds(new Set(filteredStudents.map((s) => s.id)));
    }
  };

  const handleToggleStudent = (id: string) => {
    const next = new Set(selectedStudentIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedStudentIds(next);
  };

  const handlePrint = () => {
    window.print();
  };

  const studentsToPrint = filteredStudents.filter((s) => selectedStudentIds.has(s.id));

  return (
    <div className="space-y-6">
      {/* Top Banner & Print Controls (Hidden on Print) */}
      <div className="print:hidden space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-6 rounded-3xl shadow-xl">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <QrCode className="w-5 h-5 text-indigo-400" />
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Cetak Kartu & Kode QR Siswa
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Desain kartu presensi QR Code siap cetak berdasarkan identitas NIS siswa
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handlePrint}
              disabled={studentsToPrint.length === 0}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak {studentsToPrint.length} Kartu Terpilih</span>
            </button>
          </div>
        </div>

        {/* Filter & Options Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-4 rounded-2xl text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleToggleSelectAll}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all font-semibold"
            >
              {selectedStudentIds.size === filteredStudents.length && filteredStudents.length > 0 ? (
                <CheckSquare className="w-4 h-4 text-emerald-400" />
              ) : (
                <Square className="w-4 h-4 text-slate-400" />
              )}
              <span>
                {selectedStudentIds.size === filteredStudents.length && filteredStudents.length > 0
                  ? 'Batal Pilih Semua'
                  : 'Pilih Semua Siswa'}
              </span>
            </button>

            <div className="flex items-center gap-2">
              <span className="text-slate-400">Filter Gender:</span>
              <select
                value={selectedGender}
                onChange={(e) => setSelectedGender(e.target.value)}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="SEMUA">Semua ({students.length})</option>
                <option value="L">Laki-laki (L)</option>
                <option value="P">Perempuan (P)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Model Kartu:</span>
            <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800">
              <button
                onClick={() => setCardLayout('id_card')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
                  cardLayout === 'id_card'
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <IdCard className="w-3.5 h-3.5" />
                <span>Kartu Identitas</span>
              </button>
              <button
                onClick={() => setCardLayout('compact_badge')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
                  cardLayout === 'compact_badge'
                    ? 'bg-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Stiker Mini</span>
              </button>
            </div>
          </div>
        </div>

        {/* Informative Hint */}
        <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 text-xs text-indigo-300 flex items-center gap-2.5">
          <Info className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>
            <strong>Tips Cetak:</strong> Klik tombol "Cetak Kartu Terpilih", kemudian pada dialog cetak browser pilih ukuran kertas <strong>A4</strong> dan aktifkan opsi <strong>"Background graphics / Grafik latar belakang"</strong> untuk hasil maksimal.
          </span>
        </div>
      </div>

      {/* Cards Display Grid (Styled for both Screen & Print) */}
      {studentsToPrint.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/60 rounded-3xl border border-slate-800 text-slate-400 text-xs print:hidden">
          Tidak ada siswa yang dipilih untuk dicetak.
        </div>
      ) : (
        <div
          className={`grid gap-5 ${
            cardLayout === 'id_card'
              ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3 print:grid-cols-2 print:gap-4'
              : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 print:grid-cols-4 print:gap-2'
          }`}
        >
          {studentsToPrint.map((student) => (
            <StudentQrCardItem
              key={student.id}
              student={student}
              config={config}
              layout={cardLayout}
              isSelected={selectedStudentIds.has(student.id)}
              onToggleSelect={() => handleToggleStudent(student.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface StudentQrCardItemProps {
  student: Student;
  config: AppConfig;
  layout: 'id_card' | 'compact_badge';
  isSelected: boolean;
  onToggleSelect: () => void;
}

const StudentQrCardItem: React.FC<StudentQrCardItemProps> = ({
  student,
  config,
  layout,
  isSelected,
  onToggleSelect,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    // Generate high quality QR code data URL using NIS
    QRCode.toDataURL(student.nis, {
      width: 400,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'H',
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('Failed to generate QR', err));
  }, [student.nis]);

  const handleDownloadSinglePng = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.download = `QR_${student.nis}_${student.nama.replace(/\s+/g, '_')}.png`;
    link.href = qrDataUrl;
    link.click();
  };

  if (layout === 'compact_badge') {
    return (
      <div
        onClick={onToggleSelect}
        className={`relative p-3 rounded-2xl transition-all cursor-pointer border print:border-slate-400 print:bg-white print:text-black ${
          isSelected
            ? 'bg-slate-900 border-indigo-500 shadow-md'
            : 'bg-slate-900/60 border-slate-800 opacity-60'
        }`}
      >
        <div className="bg-white p-2 rounded-xl text-center shadow-sm">
          {qrDataUrl ? (
            <img src={qrDataUrl} alt={student.nama} className="w-full aspect-square object-contain mx-auto" />
          ) : (
            <div className="w-full aspect-square bg-slate-100 flex items-center justify-center text-slate-400 text-[10px]">
              Membuat QR...
            </div>
          )}
        </div>
        <div className="mt-2 text-center">
          <div className="text-[11px] font-bold text-white print:text-black line-clamp-1">
            {student.nama}
          </div>
          <div className="text-[10px] font-mono font-bold text-indigo-300 print:text-slate-800">
            NIS: {student.nis} ({student.jenisKelamin})
          </div>
        </div>
      </div>
    );
  }

  // ID Card Full Format
  return (
    <div
      onClick={onToggleSelect}
      className={`relative rounded-3xl overflow-hidden transition-all cursor-pointer border print:border-2 print:border-slate-800 print:bg-white print:text-black print:break-inside-avoid print:shadow-none shadow-xl ${
        isSelected
          ? 'bg-slate-900 border-indigo-500/80 shadow-indigo-500/10'
          : 'bg-slate-900/50 border-slate-800 opacity-60'
      }`}
    >
      {/* Top Kop / Card Header */}
      <div className="p-4 bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 print:from-slate-100 print:to-slate-200 border-b border-indigo-800/40 print:border-slate-300 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-white p-1 border border-slate-200 shadow-sm shrink-0 flex items-center justify-center">
          {config.logoBase64 ? (
            <img
              src={config.logoBase64}
              alt={config.schoolName}
              className="w-full h-full object-contain"
            />
          ) : (
            <School className="w-5 h-5 text-indigo-700" />
          )}
        </div>
        <div className="min-w-0">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-amber-400 print:text-indigo-900 block">
            KARTU PRESENSI DIGITAL
          </span>
          <h4 className="text-xs font-black text-white print:text-slate-900 uppercase truncate">
            {config.schoolName}
          </h4>
          <p className="text-[9px] text-slate-300 print:text-slate-600 truncate">
            {config.schoolAddress}
          </p>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 sm:p-5 flex flex-col sm:flex-row items-center gap-4 bg-slate-900/95 print:bg-white">
        {/* QR Code Container */}
        <div className="p-2.5 bg-white rounded-2xl shadow-md border border-slate-200 shrink-0 text-center">
          {qrDataUrl ? (
            <img
              src={qrDataUrl}
              alt={`QR ${student.nama}`}
              className="w-28 h-28 sm:w-32 sm:h-32 object-contain"
            />
          ) : (
            <div className="w-28 h-28 sm:w-32 sm:h-32 flex items-center justify-center text-slate-400 text-xs">
              Generating...
            </div>
          )}
          <span className="text-[9px] font-mono text-slate-700 font-bold block mt-1 tracking-wider">
            NIS: {student.nis}
          </span>
        </div>

        {/* Student Details */}
        <div className="min-w-0 flex-1 space-y-2 text-center sm:text-left">
          <div>
            <span className="text-[9px] font-semibold text-indigo-400 print:text-indigo-700 uppercase tracking-wider">
              Nama Lengkap Siswa
            </span>
            <div className="text-sm font-black text-white print:text-slate-900 leading-tight">
              {student.nama}
            </div>
          </div>

          <div className="pt-1">
            <span className="text-[8px] text-slate-400 print:text-slate-500 block uppercase">
              Nomor Induk Siswa (NIS)
            </span>
            <span className="text-sm font-extrabold text-indigo-300 print:text-slate-900 font-mono">
              {student.nis}
            </span>
          </div>

          <div>
            <span className="text-[8px] text-slate-400 print:text-slate-500 block uppercase">
              Jenis Kelamin
            </span>
            <span
              className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${
                student.jenisKelamin === 'L'
                  ? 'bg-blue-500/20 text-blue-300 print:text-blue-900'
                  : 'bg-pink-500/20 text-pink-300 print:text-pink-900'
              }`}
            >
              {student.jenisKelamin === 'L' ? 'Laki-laki (L)' : 'Perempuan (P)'}
            </span>
          </div>
        </div>
      </div>

      {/* Card Footer */}
      <div className="px-4 py-2 bg-slate-950/90 print:bg-slate-50 border-t border-slate-800 print:border-slate-200 flex items-center justify-between text-[9px] text-slate-400 print:text-slate-600">
        <span className="truncate">Tunjukkan kartu ini saat scan presensi</span>
        <div className="flex items-center gap-2">
          <span className="font-semibold text-amber-400 print:text-slate-800">
            {config.footerLegal}
          </span>
          <button
            onClick={handleDownloadSinglePng}
            title="Download QR code saja (PNG)"
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 print:hidden"
          >
            <Download className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
