import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Search,
  Filter,
  CheckCircle2,
  ClockAlert,
  AlertOctagon,
  CalendarCheck,
  Edit3,
  Trash2,
  PlusCircle,
  X,
  School,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { AppConfig, AttendanceRecord, AttendanceStatus, Student } from '../types/index.ts';
import { filterAttendanceRecords } from '../utils/attendanceLogic.ts';
import { getCurrentTimeString, getTodayDateString } from '../utils/storage.ts';

interface RecapViewProps {
  records: AttendanceRecord[];
  students: Student[];
  config: AppConfig;
  onUpdateRecords: (records: AttendanceRecord[]) => void;
}

export const RecapView: React.FC<RecapViewProps> = ({
  records,
  students,
  config,
  onUpdateRecords,
}) => {
  const today = getTodayDateString();

  // Filters
  const [startDate, setStartDate] = useState<string>(today);
  const [endDate, setEndDate] = useState<string>(today);
  const [selectedStatus, setSelectedStatus] = useState<string>('SEMUA');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Edit / Manual Modal
  const [editingRecord, setEditingRecord] = useState<AttendanceRecord | null>(null);
  const [isManualModalOpen, setIsManualModalOpen] = useState<boolean>(false);

  // Manual Form
  const [manualStudentId, setManualStudentId] = useState<string>(students[0]?.id || '');
  const [manualDate, setManualDate] = useState<string>(today);
  const [manualTime, setManualTime] = useState<string>(getCurrentTimeString());
  const [manualStatus, setManualStatus] = useState<AttendanceStatus>('Hadir');
  const [manualKeterangan, setManualKeterangan] = useState<string>('');

  // Quick filter presets
  const applyDatePreset = (preset: 'today' | 'yesterday' | 'week' | 'month' | 'all') => {
    const now = new Date();
    if (preset === 'today') {
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'yesterday') {
      const yesterday = new Date(now);
      yesterday.setDate(now.getDate() - 1);
      const yStr = yesterday.toISOString().slice(0, 10);
      setStartDate(yStr);
      setEndDate(yStr);
    } else if (preset === 'week') {
      const past7 = new Date(now);
      past7.setDate(now.getDate() - 7);
      setStartDate(past7.toISOString().slice(0, 10));
      setEndDate(today);
    } else if (preset === 'month') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
      setStartDate(firstDay);
      setEndDate(today);
    } else if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    }
  };

  const filtered = filterAttendanceRecords(records, {
    startDate: startDate || undefined,
    endDate: endDate || undefined,
    statusFilter: selectedStatus,
    search: searchQuery,
  });

  // Calculate summaries for filtered view
  const summaryHadir = filtered.filter((r) => r.status === 'Hadir').length;
  const summaryTerlambat = filtered.filter((r) => r.status === 'Terlambat').length;
  const summaryIzin = filtered.filter((r) => r.status === 'Izin').length;
  const summarySakit = filtered.filter((r) => r.status === 'Sakit').length;
  const summaryAlpa = filtered.filter((r) => r.status === 'Alpa').length;

  // Export to Excel XLSX
  const handleExportExcel = () => {
    const exportData = filtered.map((r, i) => ({
      No: i + 1,
      Tanggal: r.tanggal,
      'Jam Masuk': r.waktuMasuk,
      'Jam Pulang': r.waktuPulang || '-',
      NIS: r.nis,
      'Nama Siswa': r.nama,
      Status: r.status,
      Keterangan: r.keterangan || '-',
      Metode: r.metode === 'QR_SCAN' ? 'Scan QR Kamera' : 'Input Manual Admin',
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Rekap Presensi');

    const fileName = `Rekap_Presensi_${config.schoolName.replace(/\s+/g, '_')}_${startDate || 'Semua'}_sampai_${endDate || 'HariIni'}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDeleteRecord = (id: string) => {
    if (confirm('Yakin ingin menghapus catatan presensi ini?')) {
      const updated = records.filter((r) => r.id !== id);
      onUpdateRecords(updated);
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRecord) return;
    const updated = records.map((r) => (r.id === editingRecord.id ? editingRecord : r));
    onUpdateRecords(updated);
    setEditingRecord(null);
  };

  const handleSaveManualAttendance = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find((s) => s.id === manualStudentId);
    if (!student) return;

    const newRecord: AttendanceRecord = {
      id: `att-${manualDate}-${student.id}-${Date.now()}`,
      studentId: student.id,
      nis: student.nis,
      nama: student.nama,
      tanggal: manualDate,
      waktuMasuk: manualTime,
      status: manualStatus,
      keterangan: manualKeterangan.trim() || undefined,
      metode: 'MANUAL',
      timestamp: Date.now(),
    };

    onUpdateRecords([newRecord, ...records]);
    setIsManualModalOpen(false);
    setManualKeterangan('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header Controls (Hidden on Print) */}
      <div className="print:hidden space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-6 rounded-3xl shadow-xl">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <FileSpreadsheet className="w-5 h-5 text-indigo-400" />
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Rekapitulasi Presensi Siswa
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Laporan kehadiran komprehensif, ekspor spreadsheet Excel & cetak format resmi
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setIsManualModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center gap-2 transition-all"
            >
              <PlusCircle className="w-4 h-4 text-indigo-400" />
              <span>Input Presensi Manual</span>
            </button>

            <button
              onClick={handleExportExcel}
              disabled={filtered.length === 0}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-all disabled:opacity-40"
            >
              <Download className="w-4 h-4" />
              <span>Ekspor ke Excel (.xlsx)</span>
            </button>

            <button
              onClick={handlePrint}
              disabled={filtered.length === 0}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all disabled:opacity-40"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Laporan Resmi</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl space-y-3">
          {/* Preset Buttons */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-400 font-semibold">Rentang Cepat:</span>
            <button
              onClick={() => applyDatePreset('today')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                startDate === today && endDate === today
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              Hari Ini
            </button>
            <button
              onClick={() => applyDatePreset('yesterday')}
              className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-semibold transition-all"
            >
              Kemarin
            </button>
            <button
              onClick={() => applyDatePreset('week')}
              className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-semibold transition-all"
            >
              7 Hari Terakhir
            </button>
            <button
              onClick={() => applyDatePreset('month')}
              className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-semibold transition-all"
            >
              Bulan Ini
            </button>
            <button
              onClick={() => applyDatePreset('all')}
              className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-semibold transition-all"
            >
              Semua Waktu
            </button>
          </div>

          {/* Detailed Filter Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-800/80 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Dari Tanggal:</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Sampai Tanggal:</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Status Kehadiran:</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="SEMUA">Semua Status</option>
                <option value="Hadir">Hadir Tepat Waktu</option>
                <option value="Terlambat">Terlambat</option>
                <option value="Izin">Izin</option>
                <option value="Sakit">Sakit</option>
                <option value="Alpa">Alpa</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Pencarian:</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Nama / NIS..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Filter Summary Metric Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Total Rekap</span>
            <div className="text-xl font-black text-white">{filtered.length}</div>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-center">
            <span className="text-[10px] text-emerald-400 uppercase font-bold">Hadir Tepat</span>
            <div className="text-xl font-black text-emerald-400">{summaryHadir}</div>
          </div>
          <div className="p-3 rounded-2xl bg-amber-950/30 border border-amber-500/30 text-center">
            <span className="text-[10px] text-amber-400 uppercase font-bold">Terlambat</span>
            <div className="text-xl font-black text-amber-400">{summaryTerlambat}</div>
          </div>
          <div className="p-3 rounded-2xl bg-sky-950/30 border border-sky-500/30 text-center">
            <span className="text-[10px] text-sky-400 uppercase font-bold">Izin</span>
            <div className="text-xl font-black text-sky-400">{summaryIzin}</div>
          </div>
          <div className="p-3 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 text-center">
            <span className="text-[10px] text-indigo-400 uppercase font-bold">Sakit</span>
            <div className="text-xl font-black text-indigo-400">{summarySakit}</div>
          </div>
          <div className="p-3 rounded-2xl bg-rose-950/30 border border-rose-500/30 text-center">
            <span className="text-[10px] text-rose-400 uppercase font-bold">Alpa</span>
            <div className="text-xl font-black text-rose-400">{summaryAlpa}</div>
          </div>
        </div>
      </div>

      {/* Official Print Header */}
      <div className="hidden print:block pb-4 mb-4 border-b-2 border-black text-black">
        <div className="flex items-center gap-4">
          {config.logoBase64 && (
            <img src={config.logoBase64} alt={config.schoolName} className="w-16 h-16 object-contain" />
          )}
          <div className="flex-1 text-center">
            <h2 className="text-base font-bold uppercase tracking-wider">{config.schoolName}</h2>
            <p className="text-xs">{config.schoolTagline}</p>
            <p className="text-[10px]">{config.schoolAddress} • Telp: {config.schoolPhone}</p>
            <h3 className="text-xs font-bold mt-2 uppercase underline">
              LAPORAN REKAPITULASI PRESENSI SISWA
            </h3>
            <p className="text-[10px]">
              Periode: {startDate || 'Awal'} s.d. {endDate || 'Sekarang'}
            </p>
          </div>
        </div>
      </div>

      {/* Recap Table */}
      <div className="bg-slate-900/90 print:bg-white border border-slate-800 print:border-black rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 print:text-black">
            <thead className="bg-slate-950/80 print:bg-slate-100 text-slate-400 print:text-black uppercase text-[10px] tracking-wider border-b border-slate-800 print:border-black">
              <tr>
                <th className="py-3 px-3 w-14">No</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Waktu Masuk</th>
                <th className="py-3 px-3">Waktu Pulang</th>
                <th className="py-3 px-3">NIS</th>
                <th className="py-3 px-3">Nama Siswa</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3">Keterangan</th>
                <th className="py-3 px-3 print:hidden text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 print:divide-slate-300 font-sans">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500 print:text-black">
                    Tidak ditemukan data rekap presensi pada filter yang dipilih.
                  </td>
                </tr>
              ) : (
                filtered.map((record, idx) => (
                  <tr key={record.id} className="hover:bg-slate-800/40 print:hover:bg-white transition-colors">
                    <td className="py-3 px-3 font-mono text-slate-500 print:text-black">{idx + 1}</td>
                    <td className="py-3 px-3 font-mono font-medium">{record.tanggal}</td>
                    <td className="py-3 px-3 font-mono text-emerald-400 print:text-black font-bold">
                      {record.waktuMasuk}
                    </td>
                    <td className="py-3 px-3 font-mono text-indigo-300 print:text-black">
                      {record.waktuPulang || '-'}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-indigo-300 print:text-black">{record.nis}</td>
                    <td className="py-3 px-3 font-bold text-white print:text-black">{record.nama}</td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          record.status === 'Hadir'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 print:border-black print:text-black'
                            : record.status === 'Terlambat'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 print:border-black print:text-black'
                            : 'bg-sky-500/20 text-sky-400 border border-sky-500/30 print:border-black print:text-black'
                        }`}
                      >
                        {record.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 print:text-black text-[11px]">
                      {record.keterangan || (record.metode === 'QR_SCAN' ? 'Scan Kamera' : 'Manual')}
                    </td>
                    <td className="py-3 px-3 print:hidden text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingRecord(record)}
                          title="Ubah Status/Keterangan"
                          className="p-1.5 rounded-lg bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 transition-all"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteRecord(record.id)}
                          title="Hapus Catatan"
                          className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Signatures for Printed Report */}
      <div className="hidden print:grid grid-cols-2 gap-8 pt-10 text-black text-xs text-center break-inside-avoid">
        <div>
          <p>Mengetahui,</p>
          <p className="font-bold">Kepala {config.schoolName}</p>
          <div className="h-20" />
          <p className="font-bold underline">{config.headmaster}</p>
          <p className="text-[10px]">NIP. 19750812 200212 1 004</p>
        </div>

        <div>
          <p>Bandung, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
          <p className="font-bold">Administrator / Petugas Presensi</p>
          <div className="h-20" />
          <p className="font-bold underline">{config.footerLegal.replace(/^by\s+/i, '')}</p>
          <p className="text-[10px]">Petugas Sistem Presensi QR Code</p>
        </div>
      </div>

      {/* Modal: Edit Catatan Presensi */}
      {editingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">Ubah Catatan Presensi</h3>
              <button
                onClick={() => setEditingRecord(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div>
                <span className="text-xs text-slate-400 block">Siswa:</span>
                <span className="text-sm font-bold text-white">{editingRecord.nama}</span>
                <span className="text-xs text-indigo-300 ml-2 font-mono font-bold">(NIS: {editingRecord.nis})</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Status Kehadiran
                </label>
                <select
                  value={editingRecord.status}
                  onChange={(e) =>
                    setEditingRecord({
                      ...editingRecord,
                      status: e.target.value as AttendanceStatus,
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                >
                  <option value="Hadir">Hadir</option>
                  <option value="Terlambat">Terlambat</option>
                  <option value="Izin">Izin</option>
                  <option value="Sakit">Sakit</option>
                  <option value="Alpa">Alpa</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Keterangan (Alasan Izin / Sakit / Catatan)
                </label>
                <textarea
                  rows={2}
                  value={editingRecord.keterangan || ''}
                  onChange={(e) =>
                    setEditingRecord({
                      ...editingRecord,
                      keterangan: e.target.value,
                    })
                  }
                  placeholder="Contoh: Ada surat izin dari orang tua..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingRecord(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs text-slate-300"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Input Presensi Manual Baru */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">Input Presensi Manual</h3>
              <button
                onClick={() => setIsManualModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveManualAttendance} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Pilih Siswa <span className="text-rose-400">*</span>
                </label>
                <select
                  value={manualStudentId}
                  onChange={(e) => setManualStudentId(e.target.value)}
                  required
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.nama} (NIS: {s.nis} - {s.jenisKelamin})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Tanggal Presensi
                  </label>
                  <input
                    type="date"
                    value={manualDate}
                    onChange={(e) => setManualDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Jam Presensi
                  </label>
                  <input
                    type="time"
                    step="1"
                    value={manualTime}
                    onChange={(e) => setManualTime(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Status Kehadiran
                </label>
                <select
                  value={manualStatus}
                  onChange={(e) => setManualStatus(e.target.value as AttendanceStatus)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                >
                  <option value="Hadir">Hadir</option>
                  <option value="Terlambat">Terlambat</option>
                  <option value="Izin">Izin (Disertai Surat)</option>
                  <option value="Sakit">Sakit (Disertai Surat Dokter)</option>
                  <option value="Alpa">Alpa (Tanpa Keterangan)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Keterangan Tambahan
                </label>
                <textarea
                  rows={2}
                  value={manualKeterangan}
                  onChange={(e) => setManualKeterangan(e.target.value)}
                  placeholder="Misal: Surat keterangan terlampir..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsManualModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs text-slate-300"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow"
                >
                  Simpan Presensi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
