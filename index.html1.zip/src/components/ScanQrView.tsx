import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  CameraOff,
  SwitchCamera,
  ScanLine,
  CheckCircle2,
  ClockAlert,
  AlertCircle,
  Sparkles,
  Volume2,
  VolumeX,
  RefreshCw,
  User,
  Upload,
  Clock,
  Pause,
  Play,
} from 'lucide-react';
import jsQR from 'jsqr';
import { AppConfig, AttendanceRecord, AttendanceStatus, ScanMode, Student } from '../types/index.ts';
import { calculateAttendanceStatus, parseStudentQRData } from '../utils/attendanceLogic.ts';
import { getCurrentTimeString, getTodayDateString } from '../utils/storage.ts';
import { sound } from '../utils/sound.ts';

interface ScanQrViewProps {
  students: Student[];
  records: AttendanceRecord[];
  config: AppConfig;
  onRecordAttendance: (newRecord: AttendanceRecord) => void;
}

export const ScanQrView: React.FC<ScanQrViewProps> = ({
  students,
  records,
  config,
  onRecordAttendance,
}) => {
  const [scanMode, setScanMode] = useState<ScanMode>('masuk');
  const [isCameraActive, setIsCameraActive] = useState<boolean>(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);

  // Recent scan result popup card
  const [lastScannedStudent, setLastScannedStudent] = useState<{
    student: Student;
    record: AttendanceRecord;
    isDuplicate?: boolean;
    minutesDiff?: number;
  } | null>(null);

  // Manual test / simulation input
  const [manualNis, setManualNis] = useState('');
  const [scanFeedbackMessage, setScanFeedbackMessage] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const lastScannedTimeRef = useRef<{ [studentId: string]: number }>({});
  const isScanningRef = useRef<boolean>(true);

  // 1. Fetch available cameras
  useEffect(() => {
    const getDevices = async () => {
      try {
        if (!navigator.mediaDevices?.enumerateDevices) return;
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoInputs = devices.filter((d) => d.kind === 'videoinput');
        setVideoDevices(videoInputs);
        if (videoInputs.length > 0 && !selectedDeviceId) {
          setSelectedDeviceId(videoInputs[0].deviceId);
        }
      } catch (err) {
        console.warn('Could not enumerate devices', err);
      }
    };
    getDevices();
  }, [selectedDeviceId]);

  // 2. Start Camera Stream directly
  const startCamera = async () => {
    setCameraError(null);
    stopCamera();

    try {
      const constraints: MediaStreamConstraints = {
        audio: false,
        video: selectedDeviceId
          ? { deviceId: { exact: selectedDeviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
          : { facingMode: facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setIsCameraActive(true);
        startScanningLoop();
      }
    } catch (err: any) {
      console.warn('Camera access issue:', err);
      setIsCameraActive(false);
      setCameraError(
        err.name === 'NotAllowedError'
          ? 'Izin kamera ditolak oleh browser. Silakan izinkan akses kamera di browser Anda.'
          : err.name === 'NotFoundError'
          ? 'Perangkat kamera tidak ditemukan pada sistem ini. Gunakan mode simulasi di bawah.'
          : `Tidak dapat mengakses kamera: ${err.message || 'Periksa koneksi kamera'}`
      );
    }
  };

  const stopCamera = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // Switch facing mode (Front / Back)
  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
    setSelectedDeviceId('');
  };

  // 3. Process video frames with jsQR
  const startScanningLoop = () => {
    const scanFrame = () => {
      if (!isScanningRef.current) {
        animFrameRef.current = requestAnimationFrame(scanFrame);
        return;
      }

      const video = videoRef.current;
      const canvas = canvasRef.current;

      if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });

        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'dontInvert',
          });

          if (code && code.data) {
            handleProcessScannedCode(code.data);
          }
        }
      }

      animFrameRef.current = requestAnimationFrame(scanFrame);
    };

    animFrameRef.current = requestAnimationFrame(scanFrame);
  };

  // Initialize camera on mount
  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [facingMode, selectedDeviceId]);

  // Handle scanned raw QR payload
  const handleProcessScannedCode = (rawQrString: string) => {
    const parsed = parseStudentQRData(rawQrString);
    if (!parsed.valid || !parsed.nisn) {
      return;
    }

    const targetNis = parsed.nisn.trim();
    const matchedStudent = students.find(
      (s) => s.nis.trim() === targetNis || (s.nisn && s.nisn.trim() === targetNis)
    );

    if (!matchedStudent) {
      setScanFeedbackMessage(`QR terdeteksi (NIS: ${targetNis}), tetapi belum terdaftar dalam sistem.`);
      if (isSoundEnabled) sound.playWarning();
      setTimeout(() => setScanFeedbackMessage(null), 3000);
      return;
    }

    // Check debounce: prevent duplicate scanning within 4 seconds
    const nowMs = Date.now();
    const lastScanMs = lastScannedTimeRef.current[matchedStudent.id] || 0;
    if (nowMs - lastScanMs < 4000) {
      return; // debounced
    }
    lastScannedTimeRef.current[matchedStudent.id] = nowMs;

    recordStudentAttendance(matchedStudent, 'QR_SCAN');
  };

  // Common Attendance Recorder
  const recordStudentAttendance = (student: Student, metode: 'QR_SCAN' | 'MANUAL') => {
    const today = getTodayDateString();
    const timeNow = getCurrentTimeString();

    // Check if already attended today
    const existingIndex = records.findIndex(
      (r) => r.studentId === student.id && r.tanggal === today
    );

    let finalRecord: AttendanceRecord;
    let status: AttendanceStatus;

    if (scanMode === 'pulang') {
      if (existingIndex >= 0) {
        const existing = records[existingIndex];
        finalRecord = {
          ...existing,
          waktuPulang: timeNow,
          metode,
        };
      } else {
        finalRecord = {
          id: `att-${today}-${student.id}`,
          studentId: student.id,
          nis: student.nis,
          nama: student.nama,
          tanggal: today,
          waktuMasuk: timeNow,
          waktuPulang: timeNow,
          status: 'Hadir',
          metode,
          timestamp: Date.now(),
        };
      }
    } else {
      // Mode Masuk: Calculate status based on lateThreshold
      status = calculateAttendanceStatus(timeNow, config.lateThreshold);

      finalRecord = {
        id: `att-${today}-${student.id}`,
        studentId: student.id,
        nis: student.nis,
        nama: student.nama,
        tanggal: today,
        waktuMasuk: timeNow,
        status,
        metode,
        timestamp: Date.now(),
      };
    }

    // Play Sound Beep
    if (isSoundEnabled) {
      if (finalRecord.status === 'Terlambat') {
        sound.playWarning();
      } else {
        sound.playSuccess();
      }
    }

    onRecordAttendance(finalRecord);

    const [curH, curM] = timeNow.split(':').map(Number);
    const [limitH, limitM] = config.lateThreshold.split(':').map(Number);
    const minutesLate = (curH * 60 + curM) - (limitH * 60 + limitM);

    setLastScannedStudent({
      student,
      record: finalRecord,
      minutesDiff: finalRecord.status === 'Terlambat' ? Math.max(1, minutesLate) : undefined,
    });
  };

  // Manual Test Simulation Action
  const handleManualScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualNis.trim()) return;
    handleProcessScannedCode(manualNis.trim());
    setManualNis('');
  };

  // Image File Scanner Handler
  const handleImageFileScan = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imgData.data, imgData.width, imgData.height);
        if (code && code.data) {
          handleProcessScannedCode(code.data);
        } else {
          setScanFeedbackMessage('Tidak dapat menemukan QR Code pada foto yang diunggah.');
          if (isSoundEnabled) sound.playWarning();
        }
      }
    };
    img.src = URL.createObjectURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-6 rounded-3xl shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ScanLine className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Scanner Presensi QR Code Realtime
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            Kamera perangkat terhubung langsung • Batas jam masuk: <strong className="text-amber-300 font-mono">{config.lateThreshold} WIB</strong>
          </p>
        </div>

        {/* Scan Mode Switcher (Masuk vs Pulang) */}
        <div className="flex items-center gap-2">
          <div className="flex rounded-2xl bg-slate-950 p-1 border border-slate-800">
            <button
              onClick={() => setScanMode('masuk')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                scanMode === 'masuk'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Absen Masuk</span>
            </button>
            <button
              onClick={() => setScanMode('pulang')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                scanMode === 'pulang'
                  ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Absen Pulang</span>
            </button>
          </div>

          <button
            onClick={() => setIsSoundEnabled(!isSoundEnabled)}
            title={isSoundEnabled ? 'Matikan Suara Beep' : 'Aktifkan Suara Beep'}
            className={`p-2.5 rounded-xl border transition-all ${
              isSoundEnabled
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                : 'bg-slate-800 border-slate-700 text-slate-500'
            }`}
          >
            {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Scanner Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Camera Video Stream */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative rounded-3xl overflow-hidden bg-black border-2 border-slate-800 shadow-2xl aspect-[4/3] flex items-center justify-center">
            {/* Live Video Element */}
            <video
              ref={videoRef}
              className={`w-full h-full object-cover transition-opacity ${
                isCameraActive ? 'opacity-100' : 'opacity-0'
              }`}
              muted
              playsInline
              autoPlay
            />

            {/* Hidden canvas for jsQR analysis */}
            <canvas ref={canvasRef} className="hidden" />

            {/* Visual Scanner Overlay */}
            {isCameraActive && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="absolute inset-0 bg-black/30" />

                {/* Reticle Target Area */}
                <div className="relative w-64 h-64 sm:w-72 sm:h-72 border-2 border-emerald-400/70 rounded-3xl shadow-2xl flex items-center justify-center overflow-hidden">
                  <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#34d399] animate-pulse -translate-y-10" />

                  <div className="absolute top-2 left-2 w-6 h-6 border-t-4 border-l-4 border-emerald-400 rounded-tl-lg" />
                  <div className="absolute top-2 right-2 w-6 h-6 border-t-4 border-r-4 border-emerald-400 rounded-tr-lg" />
                  <div className="absolute bottom-2 left-2 w-6 h-6 border-b-4 border-l-4 border-emerald-400 rounded-bl-lg" />
                  <div className="absolute bottom-2 right-2 w-6 h-6 border-b-4 border-r-4 border-emerald-400 rounded-br-lg" />

                  <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300 bg-black/60 px-2.5 py-1 rounded-full backdrop-blur-md">
                    Arahkan QR Siswa ke Sini
                  </span>
                </div>

                <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/70 text-emerald-400 border border-emerald-500/30 backdrop-blur-md font-semibold">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    Kamera Aktif Realtime
                  </span>
                  <span className="px-3 py-1 rounded-full bg-black/70 text-white border border-slate-700 backdrop-blur-md font-mono text-[11px]">
                    Mode: {scanMode.toUpperCase()}
                  </span>
                </div>
              </div>
            )}

            {/* Camera Error or Inactive State */}
            {!isCameraActive && (
              <div className="p-6 text-center max-w-md space-y-3">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center">
                  <CameraOff className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-white">Kamera Belum Terhubung</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {cameraError || 'Aktifkan kamera perangkat Anda untuk mulai memindai kode QR secara langsung.'}
                </p>
                <div className="pt-2 flex flex-wrap justify-center gap-2">
                  <button
                    onClick={startCamera}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 transition-all"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Coba Sambungkan Ulang</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Camera Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={toggleFacingMode}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center gap-2 transition-all"
              >
                <SwitchCamera className="w-4 h-4 text-indigo-400" />
                <span>
                  {facingMode === 'environment' ? 'Kamera Belakang' : 'Kamera Depan'}
                </span>
              </button>

              {videoDevices.length > 1 && (
                <select
                  value={selectedDeviceId}
                  onChange={(e) => setSelectedDeviceId(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 max-w-[180px] truncate"
                >
                  {videoDevices.map((dev, i) => (
                    <option key={dev.deviceId} value={dev.deviceId}>
                      {dev.label || `Kamera ${i + 1}`}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="flex items-center gap-2">
              <label className="cursor-pointer px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center gap-1.5 transition-all">
                <Upload className="w-3.5 h-3.5 text-emerald-400" />
                <span>Unggah Foto QR</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageFileScan}
                  className="hidden"
                />
              </label>

              {isCameraActive ? (
                <button
                  onClick={stopCamera}
                  className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30"
                  title="Jeda Kamera"
                >
                  <Pause className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={startCamera}
                  className="p-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  title="Mulai Kamera"
                >
                  <Play className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Feedback alert banner */}
          {scanFeedbackMessage && (
            <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2 animate-bounce">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{scanFeedbackMessage}</span>
            </div>
          )}
        </div>

        {/* Right Column: Scanned Result Card & Manual Test Suite */}
        <div className="lg:col-span-5 space-y-4">
          {/* Recent Scanned Student Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <h2 className="text-sm font-bold text-white mb-3 flex items-center justify-between">
              <span>Hasil Pemindaian Terakhir</span>
              {lastScannedStudent && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-normal">
                  Baru Saja
                </span>
              )}
            </h2>

            {lastScannedStudent ? (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white font-extrabold text-xl flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/20">
                      {lastScannedStudent.student.nama.slice(0, 2).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-base font-extrabold text-white truncate">
                        {lastScannedStudent.student.nama}
                      </div>
                      <div className="text-xs text-indigo-300 font-mono font-bold mt-0.5">
                        NIS: {lastScannedStudent.student.nis}
                      </div>
                      <span
                        className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          lastScannedStudent.student.jenisKelamin === 'L'
                            ? 'bg-blue-500/20 text-blue-300'
                            : 'bg-pink-500/20 text-pink-300'
                        }`}
                      >
                        {lastScannedStudent.student.jenisKelamin === 'L' ? 'Laki-laki (L)' : 'Perempuan (P)'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Waktu Presensi</span>
                      <span className="font-mono font-bold text-white">
                        {lastScannedStudent.record.waktuMasuk} WIB
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Status Kehadiran</span>
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full font-bold text-xs mt-0.5 ${
                          lastScannedStudent.record.status === 'Hadir'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                            : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                        }`}
                      >
                        {lastScannedStudent.record.status === 'Hadir'
                          ? 'HADIR TEPAT WAKTU'
                          : `TERLAMBAT (+${lastScannedStudent.minutesDiff || ''} m)`}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>Presensi siswa berhasil diverifikasi dan tersimpan dalam sistem.</span>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 text-slate-500 text-xs space-y-2">
                <ScanLine className="w-10 h-10 mx-auto text-slate-600 animate-pulse" />
                <p>Belum ada siswa yang discan.</p>
                <p className="text-[11px] text-slate-600">
                  Arahkan QR Code kartu siswa ke kamera untuk mencatat presensi secara instan.
                </p>
              </div>
            )}
          </div>

          {/* Test & Simulation Scanner (Manual NIS Input / Student Selector) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <h2 className="text-sm font-bold text-white">
                Simulasi / Uji Coba Scan Manual
              </h2>
            </div>
            <p className="text-xs text-slate-400">
              Gunakan opsi ini jika kamera perangkat sedang tidak dapat diakses atau untuk pengujian cepat.
            </p>

            <form onSubmit={handleManualScanSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Masukkan NIS Siswa Secara Manual:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={manualNis}
                    onChange={(e) => setManualNis(e.target.value)}
                    placeholder="Contoh: 2324101"
                    className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white transition-all shadow"
                  >
                    Simulasi Scan
                  </button>
                </div>
              </div>
            </form>

            <div className="pt-2 border-t border-slate-800">
              <span className="block text-[11px] font-semibold text-slate-400 mb-2">
                Pilih Cepat Siswa dari Daftar:
              </span>
              <div className="max-h-40 overflow-y-auto space-y-1 pr-1">
                {students.slice(0, 6).map((std) => (
                  <button
                    key={std.id}
                    type="button"
                    onClick={() => recordStudentAttendance(std, 'MANUAL')}
                    className="w-full flex items-center justify-between p-2 rounded-xl bg-slate-950/60 hover:bg-slate-800 border border-slate-800 text-left text-xs text-slate-300 hover:text-white transition-all"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <User className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span className="font-medium truncate">{std.nama}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono shrink-0">
                      NIS: {std.nis} ({std.jenisKelamin})
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
