import React, { useState, useRef } from 'react';
import {
  Settings,
  Upload,
  Image as ImageIcon,
  School,
  Lock,
  Clock,
  Save,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  ShieldCheck,
  Award,
  Download,
  Database,
  Eye,
  EyeOff,
  Trash2,
} from 'lucide-react';
import { AppConfig, AttendanceRecord, Student } from '../types/index.ts';
import { DEFAULT_CONFIG, DEFAULT_SCHOOL_LOGO } from '../utils/storage.ts';

interface SettingsViewProps {
  config: AppConfig;
  onSaveConfig: (newConfig: AppConfig) => void;
  students: Student[];
  records: AttendanceRecord[];
  onResetDemoData: () => void;
  onRestoreBackup: (data: { config?: AppConfig; students?: Student[]; records?: AttendanceRecord[] }) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  config,
  onSaveConfig,
  students,
  records,
  onResetDemoData,
  onRestoreBackup,
}) => {
  // Local config form state
  const [formData, setFormData] = useState<AppConfig>({ ...config });

  // Password change states
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // General Notification
  const [saveSuccess, setSaveSuccess] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);

  // Logo file upload handler
  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('Ukuran foto logo terlalu besar. Harap gunakan foto logo di bawah 2 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      if (typeof evt.target?.result === 'string') {
        setFormData((prev) => ({
          ...prev,
          logoBase64: evt.target!.result as string,
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetLogoToDefault = () => {
    setFormData((prev) => ({
      ...prev,
      logoBase64: DEFAULT_SCHOOL_LOGO,
    }));
  };

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  // Change admin password handler
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMessage(null);

    if (currentPasswordInput !== config.adminPassword) {
      setPasswordMessage({
        type: 'error',
        text: 'Password lama tidak cocok dengan password sistem saat ini.',
      });
      return;
    }

    if (newPasswordInput.length < 4) {
      setPasswordMessage({
        type: 'error',
        text: 'Password baru minimal harus 4 karakter.',
      });
      return;
    }

    if (newPasswordInput !== confirmPasswordInput) {
      setPasswordMessage({
        type: 'error',
        text: 'Konfirmasi password baru tidak sama.',
      });
      return;
    }

    const updatedConfig = {
      ...formData,
      adminPassword: newPasswordInput,
    };
    setFormData(updatedConfig);
    onSaveConfig(updatedConfig);

    setCurrentPasswordInput('');
    setNewPasswordInput('');
    setConfirmPasswordInput('');
    setPasswordMessage({
      type: 'success',
      text: 'Password admin berhasil diperbarui!',
    });
    setTimeout(() => setPasswordMessage(null), 4000);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    const fullBackup = {
      appName: 'Absensi QR Code Siswa',
      legalNotice: config.footerLegal,
      exportedAt: new Date().toISOString(),
      config: formData,
      students,
      records,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(fullBackup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `Backup_Absensi_${formData.schoolName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import JSON Backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const json = JSON.parse(evt.target?.result as string);
        if (json.config && Array.isArray(json.students)) {
          onRestoreBackup({
            config: json.config,
            students: json.students,
            records: json.records || [],
          });
          setFormData(json.config);
          alert('Berhasil memulihkan cadangan data sistem!');
        } else {
          alert('Format file cadangan JSON tidak valid.');
        }
      } catch (err: any) {
        alert('Gagal membaca file JSON: ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-6 rounded-3xl shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Settings className="w-5 h-5 text-indigo-400" />
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Pengaturan Sistem & Identitas Instansi
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            Upload foto logo instansi, kustomisasi judul admin panel, identitas sekolah & legalitas
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          <Save className="w-4 h-4" />
          <span>Simpan Semua Pengaturan</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="font-semibold">
            Pengaturan berhasil disimpan! Perubahan logo, judul, dan identitas instansi telah diperbarui di seluruh aplikasi.
          </span>
        </div>
      )}

      {/* Main Form Sections */}
      <form onSubmit={handleSaveAll} className="space-y-6">
        {/* Section 1: Upload Foto Logo Instansi & Kustomisasi Judul Admin Panel */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex items-center gap-2 pb-4 border-b border-slate-800">
            <School className="w-5 h-5 text-indigo-400" />
            <div>
              <h2 className="text-base font-bold text-white">
                Foto Logo Instansi & Judul Admin Panel
              </h2>
              <p className="text-xs text-slate-400">
                Logo dan judul akan tampil pada header navbar, kartu cetak QR, dan kop laporan
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Logo Preview & Upload */}
            <div className="lg:col-span-4 p-5 rounded-2xl bg-slate-950/70 border border-slate-800 text-center space-y-4">
              <label className="block text-xs font-bold text-slate-200">
                Foto Logo Instansi
              </label>

              <div className="w-32 h-32 mx-auto rounded-2xl bg-slate-900 border-2 border-dashed border-indigo-500/40 p-2 flex items-center justify-center overflow-hidden shadow-inner group relative">
                {formData.logoBase64 ? (
                  <img
                    src={formData.logoBase64}
                    alt="Logo Instansi"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <ImageIcon className="w-10 h-10 text-slate-500" />
                )}
              </div>

              <input
                ref={logoInputRef}
                type="file"
                accept="image/*"
                onChange={handleLogoFileChange}
                className="hidden"
              />

              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Foto Logo Baru</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetLogoToDefault}
                  className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-all"
                >
                  <RotateCcw className="w-3 h-3 text-slate-400" />
                  <span>Kembalikan Logo Default</span>
                </button>
              </div>

              <span className="text-[10px] text-slate-400 block leading-tight">
                Format didukung: PNG, JPG, SVG, WebP. Maksimal 2 MB.
              </span>
            </div>

            {/* Title & Institutional Identity Inputs */}
            <div className="lg:col-span-8 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  Ubah Judul 'Admin Panel' <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.panelTitle}
                  onChange={(e) => setFormData({ ...formData, panelTitle: e.target.value })}
                  placeholder="Contoh: Admin Panel Absensi Siswa"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Judul ini ditampilkan pada bilah atas (navbar) dan halaman utama admin.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    Nama Sekolah / Instansi <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.schoolName}
                    onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
                    placeholder="Contoh: SMK BINTANG NUSANTARA"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    Slogan / Visi Singkat
                  </label>
                  <input
                    type="text"
                    value={formData.schoolTagline}
                    onChange={(e) => setFormData({ ...formData, schoolTagline: e.target.value })}
                    placeholder="Contoh: Mewujudkan Generasi Unggul & Berkarakter"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  Alamat Lengkap Instansi
                </label>
                <input
                  type="text"
                  value={formData.schoolAddress}
                  onChange={(e) => setFormData({ ...formData, schoolAddress: e.target.value })}
                  placeholder="Contoh: Jl. Pendidikan No. 45, Kompleks Edukasi Mandiri, Bandung"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    Nomor Telepon / WA
                  </label>
                  <input
                    type="text"
                    value={formData.schoolPhone}
                    onChange={(e) => setFormData({ ...formData, schoolPhone: e.target.value })}
                    placeholder="(022) 8765-4321"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    Email Resmi
                  </label>
                  <input
                    type="email"
                    value={formData.schoolEmail}
                    onChange={(e) => setFormData({ ...formData, schoolEmail: e.target.value })}
                    placeholder="info@sekolah.sch.id"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    Nama Kepala Sekolah
                  </label>
                  <input
                    type="text"
                    value={formData.headmaster}
                    onChange={(e) => setFormData({ ...formData, headmaster: e.target.value })}
                    placeholder="Drs. H. Mulyadi, M.M."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Waktu Presensi & Jam Keterlambatan */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex items-center gap-2 pb-4 border-b border-slate-800 mb-5">
            <Clock className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-white">
                Batas Waktu Masuk & Aturan Keterlambatan
              </h2>
              <p className="text-xs text-slate-400">
                Tentukan batas waktu siswa scan masuk sebelum terhitung 'Terlambat'
              </p>
            </div>
          </div>

          <div className="max-w-md">
            <label className="block text-xs font-bold text-slate-200 mb-1.5">
              Batas Jam Masuk Tepat Waktu (Format Jam:Menit)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="time"
                value={formData.lateThreshold}
                onChange={(e) => setFormData({ ...formData, lateThreshold: e.target.value })}
                required
                className="px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <span className="text-xs text-slate-400">
                Scan sebelum atau pada pukul <strong>{formData.lateThreshold} WIB</strong> berstatus <strong>Hadir</strong>, sesudahnya otomatis berstatus <strong>Terlambat</strong>.
              </span>
            </div>
          </div>
        </div>

        {/* Section 3: Legalitas Sistem Resmi */}
        <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6 pointer-events-none opacity-10">
            <Award className="w-40 h-40 text-amber-400" />
          </div>

          <div className="flex items-center gap-2 pb-4 border-b border-slate-800 mb-5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold text-white">
                Legalitas & Hak Cipta Sistem
              </h2>
              <p className="text-xs text-slate-400">
                Pengakuan hak cipta dan legalitas developer resmi sistem absensi
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
            <div className="sm:col-span-8 space-y-2">
              <label className="block text-xs font-bold text-slate-200">
                Tanda Legalitas Sistem di Pojok Kanan Bawah:
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={formData.footerLegal}
                  onChange={(e) => setFormData({ ...formData, footerLegal: e.target.value })}
                  required
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-amber-500/40 text-xs font-bold text-amber-300 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <p className="text-xs text-slate-400 leading-relaxed pt-1">
                Sesuai instruksi legalitas, tanda <strong className="text-amber-300">'{formData.footerLegal}'</strong> dipasang permanen pada pojok kanan bawah antarmuka pengguna sebagai tanda hak cipta dan legalitas sistem presensi terakreditasi.
              </p>
            </div>

            <div className="sm:col-span-4 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <Award className="w-4 h-4 text-amber-400" />
                <span>Terverifikasi Legal</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Sistem Absensi Siswa QR Code v2.4 • Pengembang resmi: {formData.footerLegal}
              </p>
            </div>
          </div>
        </div>

        {/* Section 4: Tombol Simpan Final */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-indigo-600 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold text-xs shadow-xl shadow-indigo-600/30 flex items-center gap-2 transition-all active:scale-[0.98]"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Semua Pengaturan</span>
          </button>
        </div>
      </form>

      {/* Separate Card: Ubah Password Login Admin */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center gap-2 pb-4 border-b border-slate-800 mb-5">
          <Lock className="w-5 h-5 text-indigo-400" />
          <div>
            <h2 className="text-base font-bold text-white">
              Ganti Password Admin Sistem (Custom Password)
            </h2>
            <p className="text-xs text-slate-400">
              Ubah password autentikasi khusus admin untuk menjaga keamanan akses instansi
            </p>
          </div>
        </div>

        {passwordMessage && (
          <div
            className={`mb-5 p-3.5 rounded-2xl text-xs flex items-center gap-2 ${
              passwordMessage.type === 'success'
                ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
                : 'bg-rose-500/15 border border-rose-500/30 text-rose-300'
            }`}
          >
            {passwordMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{passwordMessage.text}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="max-w-xl space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Password Admin Saat Ini <span className="text-rose-400">*</span>
            </label>
            <input
              type={showPassword ? 'text' : 'password'}
              value={currentPasswordInput}
              onChange={(e) => setCurrentPasswordInput(e.target.value)}
              placeholder="Masukkan password admin lama..."
              required
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Password Baru <span className="text-rose-400">*</span>
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={newPasswordInput}
                onChange={(e) => setNewPasswordInput(e.target.value)}
                placeholder="Minimal 4 karakter..."
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Konfirmasi Password Baru <span className="text-rose-400">*</span>
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPasswordInput}
                onChange={(e) => setConfirmPasswordInput(e.target.value)}
                placeholder="Ulangi password baru..."
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5"
            >
              {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{showPassword ? 'Sembunyikan Password' : 'Lihat Password'}</span>
            </button>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition-all"
            >
              Perbarui Password Admin
            </button>
          </div>
        </form>
      </div>

      {/* Separate Card: Cadangan Data & Pemulihan (Backup & Restore) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center gap-2 pb-4 border-b border-slate-800 mb-5">
          <Database className="w-5 h-5 text-indigo-400" />
          <div>
            <h2 className="text-base font-bold text-white">
              Cadangan Data & Reset Sistem
            </h2>
            <p className="text-xs text-slate-400">
              Amankan data presensi dan konfigurasi sistem dengan mencadangkan ke file JSON
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            type="button"
            onClick={handleExportBackup}
            className="p-4 rounded-2xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800 hover:border-indigo-500/50 text-left transition-all group"
          >
            <Download className="w-5 h-5 text-indigo-400 mb-2 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-white">Download Cadangan Data (JSON)</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Simpan semua data siswa, riwayat absensi, dan preferensi instansi.
            </div>
          </button>

          <label className="p-4 rounded-2xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-left transition-all group cursor-pointer">
            <Upload className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-white">Pulihkan Data (Restore)</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Muat kembali data dari file cadangan JSON yang pernah diunduh.
            </div>
            <input
              ref={backupInputRef}
              type="file"
              accept=".json"
              onChange={handleImportBackup}
              className="hidden"
            />
          </label>

          <button
            type="button"
            onClick={() => {
              if (confirm('Yakin ingin mereset data siswa dan presensi ke data demo awal?')) {
                onResetDemoData();
              }
            }}
            className="p-4 rounded-2xl bg-rose-500/10 hover:bg-rose-500/15 border border-rose-500/30 text-left transition-all group"
          >
            <RotateCcw className="w-5 h-5 text-rose-400 mb-2 group-hover:rotate-180 transition-transform" />
            <div className="text-xs font-bold text-rose-300">Reset ke Data Contoh Demo</div>
            <div className="text-[11px] text-rose-400/80 mt-1">
              Kembalikan 10 data siswa contoh dan data presensi demo.
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
