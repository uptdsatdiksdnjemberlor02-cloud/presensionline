import React, { useState, useRef } from 'react';
import {
  Users,
  UserPlus,
  Upload,
  Download,
  Search,
  Edit2,
  Trash2,
  QrCode,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  X,
  Sparkles,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Gender, Student } from '../types/index.ts';
import { validateStudentData } from '../utils/attendanceLogic.ts';

interface StudentsViewProps {
  students: Student[];
  onSaveStudents: (newStudents: Student[]) => void;
  onSelectForQr?: (student: Student) => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({
  students,
  onSaveStudents,
  onSelectForQr,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGender, setSelectedGender] = useState<string>('SEMUA');

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [previewQrStudent, setPreviewQrStudent] = useState<Student | null>(null);

  // Simplified Form State: strictly NIS, Nama, Jenis Kelamin
  const [formData, setFormData] = useState<{
    nis: string;
    nama: string;
    jenisKelamin: Gender;
  }>({
    nis: '',
    nama: '',
    jenisKelamin: 'L',
  });
  const [formErrors, setFormErrors] = useState<string[]>([]);

  // File Upload State
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [parsedPreview, setParsedPreview] = useState<Array<{ nis: string; nama: string; jenisKelamin: Gender }>>([]);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filtered Students
  const filteredStudents = students.filter((student) => {
    if (selectedGender !== 'SEMUA' && student.jenisKelamin !== selectedGender) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchName = student.nama.toLowerCase().includes(q);
      const matchNis = student.nis.toLowerCase().includes(q);
      if (!matchName && !matchNis) return false;
    }
    return true;
  });

  const handleOpenAddModal = (student?: Student) => {
    if (student) {
      setEditingStudent(student);
      setFormData({
        nis: student.nis,
        nama: student.nama,
        jenisKelamin: student.jenisKelamin,
      });
    } else {
      setEditingStudent(null);
      setFormData({
        nis: '',
        nama: '',
        jenisKelamin: 'L',
      });
    }
    setFormErrors([]);
    setIsAddModalOpen(true);
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateStudentData(formData);
    if (!validation.valid) {
      setFormErrors(validation.errors);
      return;
    }

    // Check duplicate NIS (except current editing student)
    const duplicate = students.find(
      (s) => s.nis.trim() === formData.nis.trim() && s.id !== editingStudent?.id
    );
    if (duplicate) {
      setFormErrors([`NIS '${formData.nis}' sudah terdaftar atas nama ${duplicate.nama}`]);
      return;
    }

    if (editingStudent) {
      // Edit
      const updated = students.map((s) =>
        s.id === editingStudent.id
          ? ({
              ...s,
              nis: formData.nis.trim(),
              nama: formData.nama.trim(),
              jenisKelamin: formData.jenisKelamin,
            } as Student)
          : s
      );
      onSaveStudents(updated);
    } else {
      // New Student
      const newStudent: Student = {
        id: `std-${Date.now()}`,
        nis: formData.nis.trim(),
        nama: formData.nama.trim(),
        jenisKelamin: formData.jenisKelamin,
        status: 'Aktif',
        createdAt: new Date().toISOString(),
      };
      onSaveStudents([newStudent, ...students]);
    }

    setIsAddModalOpen(false);
  };

  const handleDeleteStudent = (student: Student) => {
    if (confirm(`Yakin ingin menghapus data siswa: ${student.nama} (NIS: ${student.nis})?`)) {
      const updated = students.filter((s) => s.id !== student.id);
      onSaveStudents(updated);
    }
  };

  // Export Student List (No, NIS, Nama, Jenis Kelamin)
  const handleExportStudents = () => {
    const dataToExport = students.map((s, idx) => ({
      No: idx + 1,
      NIS: s.nis,
      Nama: s.nama,
      'Jenis Kelamin': s.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan',
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Siswa');
    XLSX.writeFile(workbook, `Data_Siswa_NIS_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Download Sample Template CSV (NIS, Nama, JenisKelamin)
  const handleDownloadTemplate = () => {
    const sampleHeaders = 'NIS,Nama,JenisKelamin\n';
    const sampleRows =
      '2324111,Bintang Ramadhan,L\n' +
      '2324112,Citra Kirana,P\n' +
      '2324113,Farhan Maulana,L\n' +
      '2324114,Gita Permata,P';

    const blob = new Blob([sampleHeaders + sampleRows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Template_Import_Siswa_NIS.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Excel / CSV File Drop or Select
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadFile(file);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const workbook = XLSX.read(bstr, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet);

        if (!rawJson || rawJson.length === 0) {
          setUploadError('File kosong atau tidak memiliki data yang valid.');
          return;
        }

        // Map strictly: NIS, Nama, JenisKelamin
        const normalized = rawJson
          .map((row: any) => {
            const nis = String(
              row.NIS || row.nis || row['No Induk'] || row['Nomor Induk'] || row.id || ''
            ).trim();
            const nama = String(
              row.Nama || row.nama || row['Nama Siswa'] || row.Name || ''
            ).trim();
            const jkRaw = String(
              row.JenisKelamin || row['Jenis Kelamin'] || row.JK || row.Gender || 'L'
            )
              .toUpperCase()
              .trim();
            const jenisKelamin: Gender = jkRaw.startsWith('P') || jkRaw === 'WANITA' || jkRaw === 'PEREMPUAN' ? 'P' : 'L';

            return {
              nis,
              nama,
              jenisKelamin,
            };
          })
          .filter((s) => s.nis && s.nama);

        if (normalized.length === 0) {
          setUploadError('Tidak ditemukan baris yang memiliki kolom NIS dan Nama.');
          return;
        }

        setParsedPreview(normalized);
      } catch (err: any) {
        setUploadError(`Gagal membaca file: ${err.message || 'Format tidak didukung'}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleConfirmImport = () => {
    if (parsedPreview.length === 0) return;

    let addedCount = 0;
    let skippedCount = 0;
    const existingNis = new Set(students.map((s) => s.nis.trim()));
    const newStudentsToAdd: Student[] = [];

    parsedPreview.forEach((item, idx) => {
      if (item.nis && !existingNis.has(item.nis.trim())) {
        existingNis.add(item.nis.trim());
        newStudentsToAdd.push({
          id: `std-import-${Date.now()}-${idx}`,
          nis: item.nis,
          nama: item.nama,
          jenisKelamin: item.jenisKelamin,
          status: 'Aktif',
          createdAt: new Date().toISOString(),
        });
        addedCount++;
      } else {
        skippedCount++;
      }
    });

    onSaveStudents([...newStudentsToAdd, ...students]);
    setIsUploadModalOpen(false);
    setUploadFile(null);
    setParsedPreview([]);
    alert(`Berhasil mengimpor ${addedCount} data siswa baru! (${skippedCount} data diabaikan karena NIS duplikat)`);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-6 rounded-3xl shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-5 h-5 text-indigo-400" />
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Manajemen Data Siswa
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            Total {students.length} siswa • Format data ringkas: <strong>No, NIS, Nama, Jenis Kelamin</strong>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => handleOpenAddModal()}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all active:scale-[0.98]"
          >
            <UserPlus className="w-4 h-4" />
            <span>Tambah Siswa Manual</span>
          </button>

          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-semibold text-xs flex items-center gap-2 transition-all"
          >
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Upload File (Excel/CSV)</span>
          </button>

          <button
            onClick={handleExportStudents}
            title="Download Data Siswa ke Excel"
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 bg-slate-900/60 border border-slate-800/80 p-4 rounded-2xl">
        <div className="sm:col-span-8 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari berdasarkan NIS atau Nama Siswa..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/70 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="sm:col-span-4">
          <select
            value={selectedGender}
            onChange={(e) => setSelectedGender(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl bg-slate-950/70 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="SEMUA">Semua Jenis Kelamin ({students.length})</option>
            <option value="L">Laki-laki (L) ({students.filter((s) => s.jenisKelamin === 'L').length})</option>
            <option value="P">Perempuan (P) ({students.filter((s) => s.jenisKelamin === 'P').length})</option>
          </select>
        </div>
      </div>

      {/* Students Data Table: Strictly No, NIS, Nama, Jenis Kelamin, Aksi */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4 font-semibold w-16 text-center">No</th>
                <th className="py-3.5 px-6 font-semibold w-40">NIS</th>
                <th className="py-3.5 px-6 font-semibold">Nama Siswa</th>
                <th className="py-3.5 px-4 font-semibold text-center w-36">Jenis Kelamin</th>
                <th className="py-3.5 px-4 font-semibold text-right w-36">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-500">
                    Tidak ditemukan data siswa yang sesuai pencarian.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student, idx) => (
                  <tr
                    key={student.id}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    <td className="py-3.5 px-4 font-mono text-slate-500 text-center">
                      {idx + 1}
                    </td>
                    <td className="py-3.5 px-6 font-mono font-bold text-indigo-300">
                      {student.nis}
                    </td>
                    <td className="py-3.5 px-6">
                      <div className="font-bold text-white text-sm group-hover:text-indigo-300 transition-colors">
                        {student.nama}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold border ${
                          student.jenisKelamin === 'L'
                            ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                            : 'bg-pink-500/15 text-pink-300 border-pink-500/30'
                        }`}
                      >
                        {student.jenisKelamin === 'L' ? 'Laki-laki (L)' : 'Perempuan (P)'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setPreviewQrStudent(student)}
                          title="Lihat Kode QR Siswa"
                          className="p-2 rounded-xl bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 transition-all"
                        >
                          <QrCode className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenAddModal(student)}
                          title="Edit Data Siswa"
                          className="p-2 rounded-xl bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 transition-all"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStudent(student)}
                          title="Hapus Siswa"
                          className="p-2 rounded-xl bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Tambah / Edit Siswa Manual (Strictly NIS, Nama, Jenis Kelamin) */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {editingStudent ? 'Edit Data Siswa' : 'Input Data Siswa'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Masukkan kolom NIS, Nama, dan Jenis Kelamin
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formErrors.length > 0 && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs space-y-1">
                {formErrors.map((err, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{err}</span>
                  </div>
                ))}
              </div>
            )}

            <form onSubmit={handleSaveStudent} className="space-y-4">
              {/* Kolom 1: NIS */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Nomor Induk Siswa (NIS) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.nis}
                  onChange={(e) => setFormData({ ...formData, nis: e.target.value })}
                  placeholder="Contoh: 2324101"
                  required
                  autoFocus
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  NIS akan dijadikan identitas unik pada Kode QR absensi
                </span>
              </div>

              {/* Kolom 2: Nama Siswa */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Nama Lengkap Siswa <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                  placeholder="Nama lengkap siswa..."
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Kolom 3: Jenis Kelamin */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Jenis Kelamin <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, jenisKelamin: 'L' })}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                      formData.jenisKelamin === 'L'
                        ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-600/30'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    <span>Laki-laki (L)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, jenisKelamin: 'P' })}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                      formData.jenisKelamin === 'P'
                        ? 'bg-pink-600 text-white border-pink-500 shadow-md shadow-pink-600/30'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    <span>Perempuan (P)</span>
                  </button>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-all"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98]"
                >
                  {editingStudent ? 'Simpan Perubahan' : 'Tambah Siswa'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Upload File (Excel / CSV) - Format Sederhana: NIS, Nama, JenisKelamin */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Upload File Data Siswa (Excel / CSV)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Cukup kolom: <strong>NIS, Nama, JenisKelamin</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsUploadModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Template Download Card */}
            <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <FileSpreadsheet className="w-6 h-6 text-indigo-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-white">Format Template Ringkas</h4>
                  <p className="text-[11px] text-slate-300">
                    Header kolom: <code className="text-amber-300">NIS,Nama,JenisKelamin</code>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleDownloadTemplate}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Template</span>
              </button>
            </div>

            {/* Drop / Pick Area */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-emerald-500/60 rounded-2xl p-8 text-center cursor-pointer bg-slate-950/50 hover:bg-slate-950 transition-all group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileChange}
                className="hidden"
              />
              <Upload className="w-10 h-10 text-slate-400 group-hover:text-emerald-400 mx-auto mb-2 transition-colors" />
              <p className="text-xs font-bold text-white mb-1">
                {uploadFile ? uploadFile.name : 'Klik untuk memilih file Excel (.xlsx) atau CSV (.csv)'}
              </p>
              <p className="text-[11px] text-slate-400">
                Otomatis membaca kolom NIS, Nama, dan Jenis Kelamin
              </p>
            </div>

            {uploadError && (
              <div className="mt-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}

            {/* Preview of Parsed Rows */}
            {parsedPreview.length > 0 && (
              <div className="mt-5 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Terdeteksi {parsedPreview.length} Siswa
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    Pratinjau:
                  </span>
                </div>

                <div className="max-h-40 overflow-y-auto border border-slate-800 rounded-xl bg-slate-950 text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase">
                      <tr>
                        <th className="p-2">NIS</th>
                        <th className="p-2">Nama</th>
                        <th className="p-2">JK</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-[11px] text-slate-300">
                      {parsedPreview.slice(0, 5).map((row, idx) => (
                        <tr key={idx}>
                          <td className="p-2 font-mono font-bold text-indigo-300">{row.nis}</td>
                          <td className="p-2 font-semibold text-white">{row.nama}</td>
                          <td className="p-2">{row.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setIsUploadModalOpen(false);
                  setParsedPreview([]);
                  setUploadFile(null);
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-all"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={parsedPreview.length === 0}
                onClick={handleConfirmImport}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold text-white shadow-lg shadow-emerald-600/30 transition-all"
              >
                Impor {parsedPreview.length} Siswa
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Quick Preview QR Code Siswa */}
      {previewQrStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl text-center">
            <button
              onClick={() => setPreviewQrStudent(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-3">
              <QrCode className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-white">{previewQrStudent.nama}</h3>
            <p className="text-xs text-indigo-300 font-mono font-bold mt-0.5">NIS: {previewQrStudent.nis}</p>
            <span
              className={`inline-block mt-2 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                previewQrStudent.jenisKelamin === 'L'
                  ? 'bg-blue-500/20 text-blue-300'
                  : 'bg-pink-500/20 text-pink-300'
              }`}
            >
              {previewQrStudent.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'}
            </span>

            <div className="my-5 p-4 bg-white rounded-2xl inline-block shadow-lg">
              <QrCodeCanvas value={previewQrStudent.nis} size={180} />
            </div>

            <p className="text-[11px] text-slate-400 max-w-xs mx-auto mb-4">
              Kode QR ini berisi identitas unik NIS: <span className="font-mono text-indigo-300 font-bold">{previewQrStudent.nis}</span>
            </p>

            <button
              onClick={() => setPreviewQrStudent(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-all"
            >
              Tutup Pratinjau
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Mini QR Canvas helper component
export const QrCodeCanvas: React.FC<{ value: string; size?: number }> = ({ value, size = 160 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  React.useEffect(() => {
    if (!canvasRef.current) return;
    import('qrcode').then((QRCode) => {
      if (canvasRef.current) {
        QRCode.toCanvas(canvasRef.current, value, {
          width: size,
          margin: 1,
          color: {
            dark: '#0f172a',
            light: '#ffffff',
          },
        });
      }
    });
  }, [value, size]);

  return <canvas ref={canvasRef} className="rounded-lg shadow-sm" />;
};
