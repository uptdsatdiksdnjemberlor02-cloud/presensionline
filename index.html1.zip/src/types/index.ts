export type Gender = 'L' | 'P';

export interface Student {
  id: string;
  nis: string;
  nama: string;
  jenisKelamin: Gender;
  nisn?: string;
  kelas?: string;
  jurusan?: string;
  kontakOrtu?: string;
  alamat?: string;
  status?: 'Aktif' | 'Nonaktif';
  createdAt?: string;
}

export type AttendanceStatus = 'Hadir' | 'Terlambat' | 'Izin' | 'Sakit' | 'Alpa';
export type ScanMode = 'masuk' | 'pulang';

export interface AttendanceRecord {
  id: string;
  studentId: string;
  nis: string;
  nisn?: string;
  nama: string;
  kelas?: string;
  tanggal: string; // YYYY-MM-DD
  waktuMasuk: string; // HH:mm:ss
  waktuPulang?: string; // HH:mm:ss
  status: AttendanceStatus;
  keterangan?: string;
  metode: 'QR_SCAN' | 'MANUAL';
  timestamp: number;
}

export interface AppConfig {
  panelTitle: string;
  schoolName: string;
  schoolTagline: string;
  schoolAddress: string;
  schoolPhone: string;
  schoolEmail: string;
  headmaster: string;
  logoBase64: string;
  lateThreshold: string; // HH:mm format, e.g. "07:15"
  adminPassword: string; // custom password
  footerLegal: string; // "by Kunti Kunanti, M.Pd."
}

export type ActiveTab = 
  | 'dashboard' 
  | 'students' 
  | 'print_qr' 
  | 'scan_qr' 
  | 'recap' 
  | 'settings';
