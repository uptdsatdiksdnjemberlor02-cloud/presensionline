import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateAttendanceStatus,
  parseStudentQRData,
  validateStudentData,
  computeAttendanceStats,
  filterAttendanceRecords,
} from './attendanceLogic.ts';
import type { Student, AttendanceRecord } from '../types/index.ts';

test('calculateAttendanceStatus assigns Hadir before or at threshold', () => {
  assert.equal(calculateAttendanceStatus('07:00', '07:15'), 'Hadir');
  assert.equal(calculateAttendanceStatus('07:15', '07:15'), 'Hadir');
  assert.equal(calculateAttendanceStatus('07:15:30', '07:15'), 'Hadir');
});

test('calculateAttendanceStatus assigns Terlambat after threshold', () => {
  assert.equal(calculateAttendanceStatus('07:16', '07:15'), 'Terlambat');
  assert.equal(calculateAttendanceStatus('08:30:00', '07:15'), 'Terlambat');
});

test('parseStudentQRData parses plain text NIS', () => {
  const result = parseStudentQRData('2324101');
  assert.equal(result.valid, true);
  assert.equal(result.nisn, '2324101');
});

test('parseStudentQRData parses SISWA: prefix format', () => {
  const result = parseStudentQRData('SISWA:2324102');
  assert.equal(result.valid, true);
  assert.equal(result.nisn, '2324102');
});

test('parseStudentQRData parses JSON qr payload with nis', () => {
  const jsonStr = JSON.stringify({ nis: '2324105', app: 'QR_ABSENSI' });
  const result = parseStudentQRData(jsonStr);
  assert.equal(result.valid, true);
  assert.equal(result.nisn, '2324105');
});

test('validateStudentData checks simplified fields (NIS, Nama, Jenis Kelamin)', () => {
  const invalid = validateStudentData({ nama: '', nis: '1' });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.length > 0);

  const valid = validateStudentData({
    nis: '2324101',
    nama: 'Ahmad Faiz',
    jenisKelamin: 'L',
  });
  assert.equal(valid.valid, true);
});

test('computeAttendanceStats aggregates numbers correctly', () => {
  const mockStudents: Student[] = [
    {
      id: 's1',
      nis: '2324101',
      nama: 'Budi',
      jenisKelamin: 'L',
      status: 'Aktif',
    },
    {
      id: 's2',
      nis: '2324102',
      nama: 'Siti',
      jenisKelamin: 'P',
      status: 'Aktif',
    },
  ];

  const mockRecords: AttendanceRecord[] = [
    {
      id: 'rec1',
      studentId: 's1',
      nis: '2324101',
      nama: 'Budi',
      tanggal: '2026-10-15',
      waktuMasuk: '07:05:00',
      status: 'Hadir',
      metode: 'QR_SCAN',
      timestamp: Date.now(),
    },
  ];

  const stats = computeAttendanceStats(mockStudents, mockRecords, '2026-10-15');
  assert.equal(stats.totalStudents, 2);
  assert.equal(stats.hadirCount, 1);
  assert.equal(stats.terlambatCount, 0);
  assert.equal(stats.belumAbsenCount, 1);
  assert.equal(stats.presentRate, 50);
});

test('filterAttendanceRecords filters by query and status', () => {
  const records: AttendanceRecord[] = [
    {
      id: '1',
      studentId: 's1',
      nis: '2324101',
      nama: 'Ahmad Zaki',
      tanggal: '2026-10-15',
      waktuMasuk: '07:00:00',
      status: 'Hadir',
      metode: 'QR_SCAN',
      timestamp: 100,
    },
    {
      id: '2',
      studentId: 's2',
      nis: '2324102',
      nama: 'Dewi Lestari',
      tanggal: '2026-10-15',
      waktuMasuk: '07:30:00',
      status: 'Terlambat',
      metode: 'QR_SCAN',
      timestamp: 200,
    },
  ];

  const filtered = filterAttendanceRecords(records, {
    statusFilter: 'Terlambat',
  });
  assert.equal(filtered.length, 1);
  assert.equal(filtered[0].nama, 'Dewi Lestari');

  const searched = filterAttendanceRecords(records, {
    search: 'zaki',
  });
  assert.equal(searched.length, 1);
  assert.equal(searched[0].nama, 'Ahmad Zaki');
});
