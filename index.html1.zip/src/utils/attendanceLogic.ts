import type { AttendanceRecord, AttendanceStatus, Student } from '../types/index.ts';

/**
 * Compare time strings (HH:mm or HH:mm:ss) against a threshold (HH:mm)
 */
export function calculateAttendanceStatus(
  scanTime: string,
  lateThreshold: string
): 'Hadir' | 'Terlambat' {
  const [scanHours, scanMinutes] = scanTime.split(':').map((v) => parseInt(v, 10) || 0);
  const [thresholdHours, thresholdMinutes] = lateThreshold.split(':').map((v) => parseInt(v, 10) || 0);

  const scanTotalMinutes = scanHours * 60 + scanMinutes;
  const thresholdTotalMinutes = thresholdHours * 60 + thresholdMinutes;

  if (scanTotalMinutes <= thresholdTotalMinutes) {
    return 'Hadir';
  }
  return 'Terlambat';
}

/**
 * Parses and verifies QR data string from QR code.
 * Supports direct NIS / NISN, JSON strings, or prefixed format 'SISWA:NIS'.
 */
export function parseStudentQRData(qrText: string): { valid: boolean; nisn: string; raw: string } {
  if (!qrText || typeof qrText !== 'string') {
    return { valid: false, nisn: '', raw: '' };
  }

  const trimmed = qrText.trim();
  if (!trimmed) {
    return { valid: false, nisn: '', raw: '' };
  }

  // Check JSON format
  if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
    try {
      const parsed = JSON.parse(trimmed);
      const idCandidate = parsed.nis || parsed.nisn || parsed.id || parsed.studentId;
      if (idCandidate) {
        return {
          valid: true,
          nisn: String(idCandidate).trim(),
          raw: trimmed,
        };
      }
    } catch {
      // not json, continue
    }
  }

  // Check prefix 'SISWA:' or 'STUDENT:'
  if (trimmed.toUpperCase().startsWith('SISWA:')) {
    const extracted = trimmed.slice(6).trim();
    return {
      valid: !!extracted,
      nisn: extracted,
      raw: trimmed,
    };
  }

  // Plain identifier (digits, alphanumeric)
  return {
    valid: true,
    nisn: trimmed,
    raw: trimmed,
  };
}

/**
 * Validates student data form fields - simplified to NIS, Nama, and Jenis Kelamin
 */
export function validateStudentData(student: Partial<Student>): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  if (!student.nis || student.nis.trim().length < 2) {
    errors.push('NIS wajib diisi minimal 2 karakter');
  }
  if (!student.nama || student.nama.trim().length < 2) {
    errors.push('Nama siswa wajib diisi minimal 2 karakter');
  }
  if (!student.jenisKelamin || (student.jenisKelamin !== 'L' && student.jenisKelamin !== 'P')) {
    errors.push('Jenis kelamin wajib dipilih (L atau P)');
  }
  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Computes dashboard statistics for a given date
 */
export function computeAttendanceStats(
  students: Student[],
  records: AttendanceRecord[],
  targetDate: string
) {
  const activeStudents = students.filter((s) => s.status !== 'Nonaktif');
  const dateRecords = records.filter((r) => r.tanggal === targetDate);

  let hadir = 0;
  let terlambat = 0;
  let izin = 0;
  let sakit = 0;
  let alpa = 0;

  const recordedStudentIds = new Set<string>();

  for (const record of dateRecords) {
    recordedStudentIds.add(record.studentId);
    if (record.status === 'Hadir') hadir++;
    else if (record.status === 'Terlambat') terlambat++;
    else if (record.status === 'Izin') izin++;
    else if (record.status === 'Sakit') sakit++;
    else if (record.status === 'Alpa') alpa++;
  }

  const totalActive = activeStudents.length;
  const totalHadirDanTerlambat = hadir + terlambat;
  const belumAbsen = Math.max(0, totalActive - recordedStudentIds.size);
  const presentRate = totalActive > 0 ? Math.round((totalHadirDanTerlambat / totalActive) * 100) : 0;

  // Breakdown by gender
  const genderBreakdown = {
    L: { total: 0, hadir: 0 },
    P: { total: 0, hadir: 0 },
  };

  for (const student of activeStudents) {
    const g = student.jenisKelamin === 'P' ? 'P' : 'L';
    genderBreakdown[g].total++;
    const isPresent = dateRecords.some(
      (r) => r.studentId === student.id && (r.status === 'Hadir' || r.status === 'Terlambat')
    );
    if (isPresent) {
      genderBreakdown[g].hadir++;
    }
  }

  return {
    totalStudents: totalActive,
    hadirCount: hadir,
    terlambatCount: terlambat,
    izinCount: izin,
    sakitCount: sakit,
    alpaCount: alpa,
    belumAbsenCount: belumAbsen,
    presentRate,
    genderBreakdown,
  };
}

/**
 * Filter attendance records for recap table
 */
export function filterAttendanceRecords(
  records: AttendanceRecord[],
  filters: {
    startDate?: string;
    endDate?: string;
    statusFilter?: string;
    search?: string;
  }
): AttendanceRecord[] {
  return records.filter((rec) => {
    if (filters.startDate && rec.tanggal < filters.startDate) return false;
    if (filters.endDate && rec.tanggal > filters.endDate) return false;
    if (filters.statusFilter && filters.statusFilter !== 'SEMUA' && rec.status !== filters.statusFilter) return false;
    if (filters.search) {
      const q = filters.search.toLowerCase().trim();
      const matchNama = rec.nama.toLowerCase().includes(q);
      const matchNis = (rec.nis || '').toLowerCase().includes(q);
      const matchNisn = (rec.nisn || '').toLowerCase().includes(q);
      if (!matchNama && !matchNis && !matchNisn) return false;
    }
    return true;
  });
}
