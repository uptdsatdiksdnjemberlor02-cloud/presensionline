import { AppConfig, AttendanceRecord, Student } from '../types/index.ts';

const STORAGE_KEYS = {
  CONFIG: 'absensi_qr_config_v1',
  STUDENTS: 'absensi_qr_students_v1',
  ATTENDANCE: 'absensi_qr_attendance_v1',
  AUTH: 'absensi_qr_auth_v1',
};

// Elegant modern SVG badge for default school logo
export const DEFAULT_SCHOOL_LOGO = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" fill="none"><rect width="200" height="200" rx="40" fill="%234338ca"/><circle cx="100" cy="100" r="76" stroke="%23fbbf24" stroke-width="6" fill="%23312e81"/><path d="M100 45 L145 70 L145 130 L100 155 L55 130 L55 70 Z" stroke="%2338bdf8" stroke-width="4" fill="%231e1b4b"/><path d="M100 65 L100 135 M70 85 L130 85 M70 115 L130 115" stroke="%23fbbf24" stroke-width="3"/><circle cx="100" cy="100" r="14" fill="%2338bdf8"/><text x="100" y="180" font-family="sans-serif" font-size="14" font-weight="bold" fill="%23f8fafc" text-anchor="middle">TUT WURI HANDAYANI</text></svg>`;

export const DEFAULT_CONFIG: AppConfig = {
  panelTitle: 'Admin Panel Absensi Siswa',
  schoolName: 'SMK BINTANG NUSANTARA',
  schoolTagline: 'Mewujudkan Generasi Unggul, Berkarakter & Berdaya Saing Global',
  schoolAddress: 'Jl. Melati Harapan No. 24, Sukamaju, Bandung, Jawa Barat',
  schoolPhone: '(022) 8765-4321 / 0812-9876-5432',
  schoolEmail: 'admin@smkbintangnusantara.sch.id',
  headmaster: 'Drs. H. Hendra Setiawan, M.Pd.',
  logoBase64: DEFAULT_SCHOOL_LOGO,
  lateThreshold: '07:15',
  adminPassword: 'admin123',
  footerLegal: 'by Kunti Kunanti, M.Pd.',
};

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'std-001',
    nis: '2324101',
    nama: 'Aditya Pratama Putra',
    jenisKelamin: 'L',
    status: 'Aktif',
  },
  {
    id: 'std-002',
    nis: '2324102',
    nama: 'Annisa Rahmawati',
    jenisKelamin: 'P',
    status: 'Aktif',
  },
  {
    id: 'std-003',
    nis: '2324103',
    nama: 'Bagas Wicaksono',
    jenisKelamin: 'L',
    status: 'Aktif',
  },
  {
    id: 'std-004',
    nis: '2324104',
    nama: 'Cantika Putri Ayu',
    jenisKelamin: 'P',
    status: 'Aktif',
  },
  {
    id: 'std-005',
    nis: '2324105',
    nama: 'Dafi Alghifari',
    jenisKelamin: 'L',
    status: 'Aktif',
  },
  {
    id: 'std-006',
    nis: '2223201',
    nama: 'Dimas Kurniawan',
    jenisKelamin: 'L',
    status: 'Aktif',
  },
  {
    id: 'std-007',
    nis: '2223202',
    nama: 'Fathiya Nur Azizah',
    jenisKelamin: 'P',
    status: 'Aktif',
  },
  {
    id: 'std-008',
    nis: '2122301',
    nama: 'Gilang Ramadhan',
    jenisKelamin: 'L',
    status: 'Aktif',
  },
  {
    id: 'std-009',
    nis: '2122302',
    nama: 'Hafizha Azzahra',
    jenisKelamin: 'P',
    status: 'Aktif',
  },
  {
    id: 'std-010',
    nis: '2122303',
    nama: 'Irfan Maulana',
    jenisKelamin: 'L',
    status: 'Aktif',
  },
];

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentTimeString(): string {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}

export function generateInitialAttendance(students: Student[]): AttendanceRecord[] {
  const today = getTodayDateString();
  const records: AttendanceRecord[] = [];

  if (students.length > 0) {
    records.push({
      id: `att-${today}-${students[0].id}`,
      studentId: students[0].id,
      nis: students[0].nis,
      nama: students[0].nama,
      tanggal: today,
      waktuMasuk: '06:55:12',
      status: 'Hadir',
      metode: 'QR_SCAN',
      timestamp: Date.now() - 3600000,
    });
  }

  if (students.length > 1) {
    records.push({
      id: `att-${today}-${students[1].id}`,
      studentId: students[1].id,
      nis: students[1].nis,
      nama: students[1].nama,
      tanggal: today,
      waktuMasuk: '07:08:44',
      status: 'Hadir',
      metode: 'QR_SCAN',
      timestamp: Date.now() - 3000000,
    });
  }

  if (students.length > 2) {
    records.push({
      id: `att-${today}-${students[2].id}`,
      studentId: students[2].id,
      nis: students[2].nis,
      nama: students[2].nama,
      tanggal: today,
      waktuMasuk: '07:22:15',
      status: 'Terlambat',
      keterangan: 'Macet di perjalanan',
      metode: 'QR_SCAN',
      timestamp: Date.now() - 2400000,
    });
  }

  if (students.length > 5) {
    records.push({
      id: `att-${today}-${students[5].id}`,
      studentId: students[5].id,
      nis: students[5].nis,
      nama: students[5].nama,
      tanggal: today,
      waktuMasuk: '07:02:18',
      status: 'Hadir',
      metode: 'QR_SCAN',
      timestamp: Date.now() - 1800000,
    });
  }

  if (students.length > 6) {
    records.push({
      id: `att-${today}-${students[6].id}`,
      studentId: students[6].id,
      nis: students[6].nis,
      nama: students[6].nama,
      tanggal: today,
      waktuMasuk: '07:00:00',
      status: 'Izin',
      keterangan: 'Mengikuti lomba olimpiade sains',
      metode: 'MANUAL',
      timestamp: Date.now() - 1200000,
    });
  }

  return records;
}

export function loadStoredConfig(): AppConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CONFIG);
    if (!raw) return DEFAULT_CONFIG;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_CONFIG, ...parsed };
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveStoredConfig(config: AppConfig): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  } catch (err) {
    console.error('Failed to save config to localStorage', err);
  }
}

export function loadStoredStudents(): Student[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(INITIAL_STUDENTS));
      return INITIAL_STUDENTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_STUDENTS;
  } catch {
    return INITIAL_STUDENTS;
  }
}

export function saveStoredStudents(students: Student[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  } catch (err) {
    console.error('Failed to save students to localStorage', err);
  }
}

export function loadStoredAttendance(): AttendanceRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    if (!raw) {
      const initial = generateInitialAttendance(INITIAL_STUDENTS);
      localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(initial));
      return initial;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveStoredAttendance(records: AttendanceRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(records));
  } catch (err) {
    console.error('Failed to save attendance records to localStorage', err);
  }
}

export function loadStoredAuth(): boolean {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUTH);
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    return !!parsed?.isAuthenticated;
  } catch {
    return false;
  }
}

export function saveStoredAuth(isAuthenticated: boolean): void {
  try {
    localStorage.setItem(
      STORAGE_KEYS.AUTH,
      JSON.stringify({ isAuthenticated, timestamp: Date.now() })
    );
  } catch (err) {
    console.error('Failed to save auth to localStorage', err);
  }
}
